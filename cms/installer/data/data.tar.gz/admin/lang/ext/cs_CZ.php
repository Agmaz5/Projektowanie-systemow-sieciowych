<?php
$lang['403description'] = 'Stránka zakázána';
$lang['404description'] = 'Stránka nenalezena';
$lang['aa_main_tab__'] = 'Hlavní';
$lang['about'] = 'O položce';
$lang['accesskey'] = 'Klávesová zkratka';
$lang['accountupdated'] = 'Uživatelský účet byl aktualizován.';
$lang['action'] = 'Akce';
$lang['actioncontains'] = 'Akce obsahuje';
$lang['actionstatus'] = 'Akce/Stav';
$lang['active'] = 'Aktivní';
$lang['add'] = 'Přidat';
$lang['addbookmark'] = 'Vložit záložku';
$lang['addcontent'] = 'Vložit nový obsah';
$lang['added_content'] = 'Přidaný obsah';
$lang['added_group'] = 'Přidaná skupina';
$lang['added_udt'] = 'Přidaný uživatelský tag';
$lang['added_user'] = 'Přidaný uživatel';
$lang['addgroup'] = 'Vložit novou skupinu';
$lang['additionaleditors'] = 'Další editoři';
$lang['additional_params'] = 'Další parametry';
$lang['adduser'] = 'Vložit nového uživatele';
$lang['addusertag'] = 'Vložit uživatelský tag';
$lang['admin'] = 'Administrace stránek';
$lang['adminaccess'] = 'Přístup k přihlášení do administrace';
$lang['admincallout'] = 'Administrační zkratky';
$lang['admindescription'] = 'Administrace stránek.';
$lang['adminhome'] = 'Administrace';
$lang['adminindent'] = 'Zobrazit obsah';
$lang['adminlog'] = 'Administrátorský záznam';
$lang['adminlogcleared'] = 'Administrátorský záznam byl úspěšně vymazán';
$lang['adminlogdescription'] = 'Zobrazí záznamy o tom, kdo co dělal v administraci.';
$lang['adminlogempty'] = 'Administrátorský záznam je prázdný';
$lang['adminlog_1day'] = '1 den';
$lang['adminlog_1month'] = '1 měsíc';
$lang['adminlog_1week'] = '1 týden';
$lang['adminlog_2weeks'] = '2 týdny';
$lang['adminlog_3months'] = '3 měsíce';
$lang['adminlog_6months'] = '6 měsíců';
$lang['adminlog_lifetime'] = 'Doba uchování zápisů v záznamu';
$lang['adminlog_manual'] = 'Ruční vymazání';
$lang['adminpaging'] = 'Počet položek obsahu pro zobrazení na stránku v seznamu';
$lang['adminpaneltitle'] = 'CMS Made Simple administrační panel';
$lang['adminplugin'] = 'Admin plugin';
$lang['adminprefs'] = 'Nastavení administrace';
$lang['adminprefsdescription'] = 'Zde jsou specifická nastavení administrace.';
$lang['adminspecialgroup'] = 'Varování: Členové této skupiny mají automaticky všechna oprávnění';
$lang['adminsystemtitle'] = 'Administrace CMS systému';
$lang['admintheme'] = 'Vzhled administrace';
$lang['admin_enablenotifications'] = 'Povolit zobrazování upozornění uživatelům<br/><em>(upozornění budou zobrazována na všech administrátorských stránkách)</em>';
$lang['admin_layout_legend'] = 'Nastavení rozložení administrace';
$lang['admin_lock_timeout'] = 'Časový limit zámku';
$lang['advanced'] = 'Rozšířené';
$lang['alert'] = 'Výstraha';
$lang['alerts'] = 'Výstrahy';
$lang['alias'] = 'Alias';
$lang['aliasalreadyused'] = 'Alias již byl použit na jiné stránce. Změňte "Alias stránky" na kartě "Nastavení" na něco jiného.';
$lang['aliasmustbelettersandnumbers'] = 'Alias musí obsahovat jen znaky a čísla';
$lang['aliasnotaninteger'] = 'Alias nemůže být integer';
$lang['allow_browser_cache'] = 'Povolit prohlížeči kešovat stránky';
$lang['allpagesmodified'] = 'Všechny stránky upraveny!';
$lang['all_groups'] = 'Všechny skupiny';
$lang['always'] = 'Vždy';
$lang['applied'] = 'Aplikováno';
$lang['apply'] = 'Provést';
$lang['applydescription'] = 'Uložit změny a pokračovat v úpravách';
$lang['assignmentchanged'] = 'Přiřazení skupiny aktualizováno.';
$lang['assignments'] = 'Přiřadit uživatele';
$lang['author'] = 'Autor';
$lang['autoclearcache'] = 'Automaticky vymazat keš každých N dní';
$lang['autoclearcache2'] = 'Odstranit soubory keše starší nez zadaný počet dní';
$lang['autoinstallupgrade'] = 'Automaticky instalovat nebo aktualizovat';
$lang['automatedtask_success'] = 'Automatizovaný úkol proveden';
$lang['back'] = 'Zpět do menu';
$lang['backtoplugins'] = 'Zpět na seznam pluginů';
$lang['basic_attributes'] = 'Základní vlastnosti';
$lang['bookmarks'] = 'Záložky';
$lang['browser_cache_expiry'] = 'Interval vypršení keše prohlížeče <em>(minuty)</em>';
$lang['browser_cache_settings'] = 'Nastavení keše prohlížeče';
$lang['bulk_success'] = 'Operace byla úspěšně aktualizována.';
$lang['cachable'] = 'Lze kešovat';
$lang['cachecleared'] = 'Cache vymazána';
$lang['cachenotwritable'] = 'Do adresář Cache nelze zapisovat. Vymazání cache nebude fungovat. Nastavte prosím adresáři tmp/cache plná oprávnění pro čtení/zápis/spouštění (chmod 777). Také možná bude potřeba vypnout safe mode.';
$lang['cancel'] = 'Storno';
$lang['canceldescription'] = 'Zrušit změny';
$lang['cantchmodfiles'] = 'Nešlo změnit práva některých souborů';
$lang['cantremove'] = 'Nelze odstranit';
$lang['cantremovefiles'] = 'Chyba odstranění souborů (oprávnění?)';
$lang['caution'] = 'Pozor';
$lang['changehistory'] = 'Historie změn';
$lang['changeowner'] = 'Změnit vlastníka';
$lang['changepermissions'] = 'Změnit oprávnění';
$lang['checksumdescription'] = 'Zkontrolovat integritu souborů CMS porovnáním se známými kontrolními součty';
$lang['checksum_passed'] = 'Všechny kontrolní součty odpovídají těm v nahrávaném souboru';
$lang['checkversion'] = 'Povolit pravidelné kontroly nových verzí';
$lang['check_ini_set'] = 'Testovat ini_set';
$lang['check_ini_set_off'] = 'Můžete mít potíže s nějakou funkcionalitou bez této možnosti. Tento test může selhat pokud máte povolený safe_mode';
$lang['choose'] = 'Zvolit';
$lang['clear'] = 'Vymazat';
$lang['clearadminlog'] = 'Vymazat administrátorský záznam';
$lang['clearcache'] = 'Vymazat cache';
$lang['clearcache_taskdescription'] = 'Spouštěno denně, tato úloha vymaže soubory keše starší než doba udaná v globálním nastavení';
$lang['clearcache_taskname'] = 'Vymazat soubory keše';
$lang['clearusersettings'] = 'Vymazat všechna nastavení';
$lang['close'] = 'Zavřít';
$lang['CMSEX_C001'] = 'Litujeme, ze zadaného vstupu jsme nemohli vytvořit platný alias stránky';
$lang['CMSEX_F001'] = 'Problém s oprávněním systému souborů';
$lang['CMSEX_G001'] = 'Pokus o nastavení neplatné vlastnosti do objektu';
$lang['CMSEX_L001'] = 'Pokus o odstranění zámku vlastněného jiným uživatelem, jehož platnost nevypršela';
$lang['cms_install_information'] = 'Informace o instalaci CMS';
$lang['cms_version'] = 'Verze CMS';
$lang['code'] = 'Kód';
$lang['config_information'] = 'Informace o konfiguraci';
$lang['config_writable'] = 'config.php zapisovatelný. Je mnohem bezpečnějí změnit práva na pouze pro čtení';
$lang['confirmcancel'] = 'Opravdu chcete zrušit změny? Klikněte na OK pro zrušení změn. Klikněte na Storno po pokračování v úpravách.';
$lang['confirmdefault'] = 'Opravdu si přejete nastavit stránku - %s - jako hlavní stránku prezentace?';
$lang['confirmdeletedir'] = 'Opravdu chcete smazat tento adresář a veškerý jeho obsah?';
$lang['connection_error'] = 'Odchozí HTTP spojení nefungují! Je možné, že jsou blokována firewallem nebo jiným způsobem. Správce modulů a jiné funkce nebudou dostupné.';
$lang['connection_failed'] = 'Připojení selhalo!';
$lang['content'] = 'Obsah';
$lang['contentadded'] = 'Obsah byl úspěšně přidán do databáze.';
$lang['contentdeleted'] = 'Obsah byl úspěšně odstraněn z databáze.';
$lang['contentdescription'] = 'Zde se vkládá a upravuje obsah.';
$lang['contentimage_path'] = 'Cesta tagu {content_image}';
$lang['contentmanagement'] = 'Správa obsahu';
$lang['contenttype'] = 'Typ obsahu';
$lang['contenttype_content'] = 'Obsah';
$lang['contenttype_errorpage'] = 'Stránka chyby';
$lang['contenttype_pagelink'] = 'Odkaz na jinou stránku webu';
$lang['contenttype_redirlink'] = 'Odkaz přesměrování';
$lang['contenttype_sectionheader'] = 'Nadpis sekce';
$lang['contenttype_separator'] = 'Oddělovač';
$lang['contentupdated'] = 'Obsah byl úspěšně aktualizován.';
$lang['content_autocreate_flaturls'] = 'Automaticky vytvořené URL jsou ploché';
$lang['content_autocreate_urls'] = 'Automaticky vytvořit URL stránky';
$lang['content_copied'] = 'Položka obsahu zkopírována do %s';
$lang['content_editor_legend'] = 'Nastavení editoru obsahu';
$lang['content_id'] = 'ID obsahu';
$lang['content_imagefield_path'] = 'Cesta pole obrázku';
$lang['content_mandatory_urls'] = 'URL stránky jsou vyžadovány';
$lang['content_thumbnailfield_path'] = 'Cesta pole náhledů';
$lang['contract'] = 'Sbalit sekci';
$lang['contractall'] = 'Sbalit všechny sekce';
$lang['copy'] = 'Kopírovat';
$lang['copycontent'] = 'Kopírovat položku obsahu';
$lang['copyfromuser'] = 'Uživatel';
$lang['copystylesheet'] = 'Kopírovat styl';
$lang['copytemplate'] = 'Kopírovat šablonu';
$lang['copy_from'] = 'Kopírovat z';
$lang['copy_paste_forum'] = 'Prohlédnout textové shrnutí <em>(vhodné pro zkopírování do příspěvků fóra)</em>';
$lang['copy_to'] = 'Kopírovat do';
$lang['core'] = 'Jádro';
$lang['create'] = 'Vytvořit';
$lang['createnewfolder'] = 'Vytvořit nový adresář';
$lang['create_dir_and_file'] = 'Kontroluji, zda může webový server může vytvářet soubory v jím založeném adresáři';
$lang['cron_3h'] = '3 hodiny';
$lang['cron_6h'] = '6 hodin';
$lang['cron_12h'] = '12 hodin';
$lang['cron_15m'] = '15 minut';
$lang['cron_24h'] = '24 hodin';
$lang['cron_30m'] = '30 minut';
$lang['cron_60m'] = '1 hodina';
$lang['cron_120m'] = '2 hodiny';
$lang['cron_request'] = 'Každý dotaz';
$lang['CSS'] = 'CSS';
$lang['cssalreadyused'] = 'Jméno CSS se již používá';
$lang['cssmanagement'] = 'Správa CSS';
$lang['css_max_age'] = 'Maximální doba (sekundy), po kterou může být styl kešován v prohlížeči';
$lang['currentassociations'] = 'Současná přiřazení';
$lang['currentdirectory'] = 'Současný adresář';
$lang['currentgroups'] = 'Současné skupiny';
$lang['currentpages'] = 'Současné stránky';
$lang['currenttemplates'] = 'Současné šablony';
$lang['currentusers'] = 'Současní uživatelé';
$lang['custom404'] = 'Vlastní chybové hlášení 404';
$lang['dashboard'] = 'Zobrazit Dashboard';
$lang['database'] = 'Databáze';
$lang['databaseprefix'] = 'Prefix databáze';
$lang['databasetype'] = 'Typ databáze';
$lang['date'] = 'Datum';
$lang['date_format_string'] = 'Řetězec formátu data';
$lang['date_format_string_help'] = '<em>strftime</em> formátovaný řetězec formátu data';
$lang['day'] = 'den';
$lang['days'] = 'dní';
$lang['default'] = 'Výchozí';
$lang['defaultparentpage'] = 'Výchozí nadřazená stránka';
$lang['delete'] = 'Smazat';
$lang['deleteconfirm'] = 'Opravdu chcete smazat - %s -?';
$lang['deletecontent'] = 'Smazat obsah';
$lang['deletepages'] = 'Opravdu chcete smazat tyto stránky?';
$lang['description'] = 'Popis';
$lang['destinationnotfound'] = 'Vybraná stránka nenalezena nebo není platná';
$lang['destination_page'] = 'Cílová stránka';
$lang['directoryabove'] = 'adresář nad aktuální úrovní';
$lang['directoryexists'] = 'Tento adresář již existuje.';
$lang['disable'] = 'Vypnout';
$lang['disabled'] = 'Vypnuto';
$lang['disablesafemodewarning'] = 'Zakázat administrační varování safe mode';
$lang['disable_functions'] = 'disable_functions v PHP';
$lang['disable_wysiwyg'] = 'WYSIWYG není povoleno pro tuto stránku';
$lang['disallowed_contenttypes'] = 'Content Types that are not Allowed';
$lang['documentation'] = 'Dokumentace';
$lang['down'] = 'Dolů';
$lang['download'] = 'Stažení';
$lang['download_cksum_file'] = 'Stáhnout soubor s kontrolním součtem';
$lang['ecommerce_desc'] = 'Moduly poskytující schopnosti E-commerce';
$lang['edit'] = 'Upravit';
$lang['editbookmark'] = 'Upravit záložku';
$lang['editconfiguration'] = 'Upravit nastavení';
$lang['editcontent_settings'] = 'Nastavení editace obsahu';
$lang['editeventhandler'] = 'Upravit ovladač událostí';
$lang['editgroup'] = 'Upravit skupinu';
$lang['edituser'] = 'Upravit uživatele';
$lang['editusertag'] = 'Upravit uživatelský tag';
$lang['email'] = 'Emailová adresa';
$lang['enable'] = 'Zapnout';
$lang['enablecustom404'] = 'Povolit vlastni zprávy 404';
$lang['enablenotifications'] = 'Povolit uživatelská upozornění v administrační sekci';
$lang['enablesitedown'] = 'Povolit zprávu mimo provoz';
$lang['enablewysiwyg'] = 'Povolit WYSIWYG u zprávy mimo provoz';
$lang['encoding'] = 'Kódování';
$lang['error'] = 'Chyba';
$lang['errorcantcreatefile'] = 'Nelze vytvořit soubor (chybně nastavená oprávnění?)';
$lang['errorchildcontent'] = 'K obsahu je stále přiřazena podřazená položka. Nejdříve ji prosím odstraňte.';
$lang['errordefaultpage'] = 'Nelze smazat současnou hlavní stránku. Nastavte nejříve jinou jako hlavní.';
$lang['errordeletingassociation'] = 'Chyba mazání asociace';
$lang['errordeletingcontent'] = 'Chyba při mazání obsahu (stránka má buď potomky nebo je nastavena jako výchozí)';
$lang['errordeletingdirectory'] = 'Nelze smazat adresář. Chyba práv?';
$lang['errordeletingfile'] = 'Nelze smazat soubor. Chyba práv?';
$lang['errordirectorynotwritable'] = 'Chybí oprávnění pro zápis do adresáře';
$lang['errorgettingcontent'] = 'Nelze získat informace o zadaném objektu obsahu';
$lang['errorinsertinggroup'] = 'Chyba vložení skupiny';
$lang['errorinsertingtag'] = 'Chyba vložení uživatelského tagu';
$lang['errorinsertinguser'] = 'Chyba vložení uživatele';
$lang['errormodulenotfound'] = 'Interní chyba, nelze najít instanci modulu';
$lang['errormodulenotloaded'] = 'Interní chyba, modul nebyl zaveden';
$lang['errormoduleversionincompatible'] = 'Modul není kompatibilní s touto verzí CMS';
$lang['errormodulewontload'] = 'Problém se zavedením dostupného modulu';
$lang['errornofilesexported'] = 'Chyba při exportu souborů do xml';
$lang['errorpagealreadyinuse'] = 'Kód chyby se již používá';
$lang['errorsendingemail'] = 'Nastala chyba při odesílání emailu. Kontaktujte administrátora.';
$lang['errorupdatetemplateallpages'] = 'Šablona není aktivní';
$lang['errorupdatinggroup'] = 'Chyba aktualizace skupiny';
$lang['errorupdatingpages'] = 'Chyba aktualizace stránek';
$lang['errorupdatingtemplate'] = 'Chyba aktualizace šablony';
$lang['errorupdatinguser'] = 'Chyba aktualizace uživatele';
$lang['errorupdatingusertag'] = 'Chyba aktualizace uživatelského tagu';
$lang['erroruserinuse'] = 'Tento uživatel stále vlastní stránky. Změňte vlastnictví těchto stránek na jiného uživatele před smazáním.';
$lang['error_delete_default_parent'] = 'Nemůžete smazat nadřazený prvek výchozí stránky.';
$lang['error_module_mincmsversion'] = 'Tento modul vyžaduje novější verzi CMS Made Simple';
$lang['error_nofileuploaded'] = 'Žádný soubor nebyl nahrán';
$lang['error_nograntall_found'] = 'Could not find a suitable "GRANT ALL" permission.  This may mean you could have problems installing or removing modules.  Or even adding and deleting items, including pages';
$lang['error_nomodules'] = 'Nejsou nainstalovány žádné moduly! Zkontrolujte Rozšíření > Moduly';
$lang['error_no_default_content_block'] = 'Nenalezen výchozí obsahový blok v této šabloně. Ujistěte se, že v šabloně máte tag {content}.';
$lang['error_parsing_content_blocks'] = 'Nastala chyba při parsování obsahových bloků (pravděpodobně duplicitní jména bloků)';
$lang['error_portinvalid'] = 'Neplatné číslo portu';
$lang['error_retrieving_file_list'] = 'Chyba při získávání seznamu souborů';
$lang['error_type'] = 'Typ chyby';
$lang['error_udt_name_chars'] = 'Platné jméno UDT začíná písmenem nebo podtržítkem, následuje libovolný počet písmen, čísel nebo podtržítek';
$lang['error_udt_name_whitespace'] = 'Chyba: Uživatelsky definované tagy nesmí mít mezery ve jméně.';
$lang['error_uploadproblem'] = 'Během nahrávání došlo k chybě';
$lang['error_usernamerequired'] = 'Pro ověření SMTP je vyžadováno <b>uživatelské jméno</b>';
$lang['event'] = 'Událost';
$lang['eventhandler'] = 'Ovládače událostí';
$lang['eventhandlerdescription'] = 'Přiřadit uživatelské tagy s událostmi';
$lang['eventhandlers'] = 'Správce událostí';
$lang['event_description'] = 'Popis události';
$lang['event_desc_addglobalcontentpost'] = 'Odesláno po vytvoření nového hlavního obsahového bloku';
$lang['event_desc_addglobalcontentpre'] = 'Odesláno před vytvořením nového hlavního obsahového bloku';
$lang['event_desc_addgrouppost'] = 'Odesláno po založení nové skupiny';
$lang['event_desc_addgrouppre'] = 'Odesláno před založením nové skupiny';
$lang['event_desc_addstylesheetpost'] = 'Odesláno po vytvoření nového stylu';
$lang['event_desc_addstylesheetpre'] = 'Odesláno před vytvořením nového stylu';
$lang['event_desc_addtemplatepost'] = 'Odesláno po vytvoření nové šablony';
$lang['event_desc_addtemplatepre'] = 'Odesláno před vytvořením nové šablony';
$lang['event_desc_adduserdefinedtagpost'] = 'Odesláno po vložení uživatelského tagu';
$lang['event_desc_adduserdefinedtagpre'] = 'Odesláno před vložením uživatelského tagu';
$lang['event_desc_adduserpost'] = 'Odesláno po vytvoření nového uživatele';
$lang['event_desc_adduserpre'] = 'Odesláno před vytvořením nového uživatele';
$lang['event_desc_changegroupassignpost'] = 'Odesláno po uložení přiřazení skupiny';
$lang['event_desc_changegroupassignpre'] = 'Odesláno před uložením přiřazení skupiny';
$lang['event_desc_contentdeletepost'] = 'Odesláno po smazání obsahu ze systému';
$lang['event_desc_contentdeletepre'] = 'Odesláno před smazáním obsahu ze systému';
$lang['event_desc_contenteditpost'] = 'Odesláno po uložení změn obsahu';
$lang['event_desc_contenteditpre'] = 'Odesláno před uložením změn obsahu';
$lang['event_desc_contentpostcompile'] = 'Odesláno po zpracování obsahu smarty systémem';
$lang['event_desc_contentpostrender'] = 'Odesláno před odesláním kombinovaného html prohlížeči';
$lang['event_desc_contentprecompile'] = 'Odesláno před předáním obsahu smarty systému';
$lang['event_desc_contentstylesheet'] = 'Odesláno před odesláním stylu prohlížeči';
$lang['event_desc_deleteglobalcontentpost'] = 'Odesláno po smazání hlavního obsahového bloku ze systému';
$lang['event_desc_deleteglobalcontentpre'] = 'Odesláno před smazáním hlavního obsahového bloku ze systému';
$lang['event_desc_deletegrouppost'] = 'Odesláno po smazání skupiny ze systému';
$lang['event_desc_deletegrouppre'] = 'Odesláno před smazáním skupiny ze systému';
$lang['event_desc_deletestylesheetpost'] = 'Odesláno po smazání stylu ze systému';
$lang['event_desc_deletestylesheetpre'] = 'Odesláno před smazáním stylu ze systému';
$lang['event_desc_deletetemplatepost'] = 'Odesláno po smazání šablony ze systému';
$lang['event_desc_deletetemplatepre'] = 'Odesláno před smazáním šablony ze systému';
$lang['event_desc_deleteuserdefinedtagpost'] = 'Odesláno po smazání uživatelského tagu';
$lang['event_desc_deleteuserdefinedtagpre'] = 'Odesláno před smazáním uživatelského tagu';
$lang['event_desc_deleteuserpost'] = 'Odesláno po smazání uživatele ze systému';
$lang['event_desc_deleteuserpre'] = 'Odesláno před smazáním uživatele ze systému';
$lang['event_desc_editglobalcontentpost'] = 'Odesláno po uložení změn hlavního obsahového bloku';
$lang['event_desc_editglobalcontentpre'] = 'Odesláno před uložením změn hlavního obsahového bloku';
$lang['event_desc_editgrouppost'] = 'Odesláno po uložení změn skupiny';
$lang['event_desc_editgrouppre'] = 'Odesláno před uložením změn skupiny';
$lang['event_desc_editstylesheetpost'] = 'Odesláno po uložení změn do stylu';
$lang['event_desc_editstylesheetpre'] = 'Odesláno před uložením změn do stylu';
$lang['event_desc_edittemplatepost'] = 'Odesláno po uložení změn do šablony';
$lang['event_desc_edittemplatepre'] = 'Odesláno před uložením změn do šablony';
$lang['event_desc_edituserdefinedtagpost'] = 'Odesláno po aktualizaci uživatelského tagu';
$lang['event_desc_edituserdefinedtagpre'] = 'Odesláno před aktualizací uživatelského tagu';
$lang['event_desc_edituserpost'] = 'Odesláno po uložení změn uživatele';
$lang['event_desc_edituserpre'] = 'Odesláno před uložením změn uživatele';
$lang['event_desc_globalcontentpostcompile'] = 'Odesláno po odeslání hlavního obsahového bloku ke zpracování smarty systémem';
$lang['event_desc_globalcontentprecompile'] = 'Odesláno před odesláním hlavního obsahového bloku ke zpracování smarty systémem';
$lang['event_desc_loginfailed'] = 'Failed Login';
$lang['event_desc_loginpost'] = 'Odesláno po přihlášení uživatele do administračního panelu';
$lang['event_desc_logoutpost'] = 'Odesláno po odhlášení uživatele do administračního panelu';
$lang['event_desc_moduleinstalled'] = 'Odesláno po instalaci modulu';
$lang['event_desc_moduleuninstalled'] = 'Odesláno po odinstalaci modulu';
$lang['event_desc_moduleupgraded'] = 'Odesláno po aktualizaci modulu';
$lang['event_desc_smartypostcompile'] = 'Odesláno po zpracování jakéhokoliv obsahu určeného pro smarty systém';
$lang['event_desc_smartyprecompile'] = 'Odesláno před zpracováním jakéhokoliv obsahu určeného pro smarty systém';
$lang['event_desc_templatepostcompile'] = 'Odesláno po předání šablony ke zpracování smarty systémem';
$lang['event_desc_templateprecompile'] = 'Odesláno před předáním šablony ke zpracování smarty systémem';
$lang['event_help_addglobalcontentpost'] = '<p>Odeslána po vytvoření nového obsahového bloku.</p>
<h4>Parametry</h4>
<ul>
<li>\'global_content\' - Odkaz na ovlivněný objekt obsahového bloku.</li>
</ul>';
$lang['event_help_addglobalcontentpre'] = '<p>Odeslána před vytvořením nového obsahového bloku.</p>
<h4>Parametry</h4>
<ul>
<li>\'global_content\' - Odkaz na ovlivněný objekt obsahového bloku.</li>
</ul>';
$lang['event_help_addgrouppost'] = '<p>Odeslána po vytvoření nové skupiny.</p>
<h4>Parametry</h4>
<ul>
<li>\'group\' - Odkaz na ovlivněný objekt skupiny.</li>
</ul>';
$lang['event_help_addgrouppre'] = '<p>Odeslána před vytvořením nové skupiny.</p>
<h4>Parametry</h4>
<ul>
<li>\'group\' - Odkaz na ovlivněný objekt skupiny.</li>
</ul>';
$lang['event_help_addstylesheetpost'] = '<p>Odeslána po vytvoření nového stylu.</p>
<h4>Parametry</h4>
<ul>
<li>\'stylesheet\' - Odkaz na ovlivněný objekt stylu.</li>
</ul>';
$lang['event_help_addstylesheetpre'] = '<p>Odeslána před vytvořením nového stylu.</p>
<h4>Parametry</h4>
<ul>
<li>\'stylesheet\' - Odkaz na ovlivněný objekt stylu.</li>
</ul>';
$lang['event_help_addtemplatepost'] = '<p>Odeslána po vytvoření nové šablony.</p>
<h4>Parametry</h4>
<ul>
<li>\'template\' - Odkaz na ovlivněný objekt šablony.</li>
</ul>';
$lang['event_help_addtemplatepre'] = '<p>Odeslána před vytvořením nové šablony.</p>
<h4>Parametry</h4>
<ul>
<li>\'template\' - Odkaz na ovlivněný objekt šablony.</li>
</ul>';
$lang['event_help_adduserdefinedtagpost'] = '<p>Odesláno před vložením uživatelského tagu.</p>';
$lang['event_help_adduserdefinedtagpre'] = '<p>Odesláno po vložení uživatelského tagu.</p>';
$lang['event_help_adduserpost'] = '<p>Odeslána po vytvoření nového uživatele.</p>
<h4>Parametry</h4>
<ul>
<li>\'user\' - Odkaz na ovlivněný uživatelský objekt.</li>
</ul>';
$lang['event_help_adduserpre'] = '<p>Odeslána před vytvořením nového uživatele.</p>
<h4>Parametry</h4>
<ul>
<li>\'user\' - Odkaz na ovlivněný uživatelský objekt.</li>
</ul>';
$lang['event_help_changegroupassignpost'] = '<p>Odeslána po uložení přiřazení skupiny.</p>
<h4>Parametry></h4>
<ul>
<li>\'group\' - Odkaz na ovlivněnou skupinu objektů.</li>
<li>\'users\' - Pole odkazů na uživatelské objekty patřící do ovlivněné skupiny.</li>';
$lang['event_help_changegroupassignpre'] = '<p>Odeslána před uložením přiřazení skupiny.</p>
<h4>Parametry></h4>
<ul>
<li>\'group\' - Odkaz na objekt skupiny.</li>
<li>\'users\' - Pole odkazů na uživatelské objekty patřící do skupiny.</li>';
$lang['event_help_contentdeletepost'] = '<p>Odeslána po vymazání obsahu ze systému.</p>
<h4>Parametry</h4>
<ul>
<li>\'content\' - Odkaz na ovlivněný objekt obsahu.</li>
</ul>';
$lang['event_help_contentdeletepre'] = '<p>Odeslána před vymazáním obsahu ze systému.</p>
<h4>Parametry</h4>
<ul>
<li>\'content\' - Odkaz na ovlivněný objekt obsahu.</li>
</ul>';
$lang['event_help_contenteditpost'] = '<p>Odeslána po uložení změn obsahu.</p>
<h4>Parametry</h4>
<ul>
<li>\'content\' - Odkaz na ovlivněný objekt obsahu.</li>
</ul>';
$lang['event_help_contenteditpre'] = '<p>Odeslána před uložením změn obsahu.</p>
<h4>Parametry</h4>
<ul>
<li>\'global_content\' - Odkaz na ovlivněný objekt obsahu.</li>
</ul>';
$lang['event_help_contentpostcompile'] = '<p>Odeslána po zpracování obsahu pomocí Smarty.</p>
<h4>Parametry</h4>
<ul>
<li>\'content\' - Odkaz na ovlivněný text obsahu.</li>
</ul>';
$lang['event_help_contentpostrender'] = '<p>Odeslána před předáním kombinovaného html prohlížeči.</p>
<h4>Parametry</h4>
<ul>
<li>\'content\' - Odkaz na html text.</li>
</ul>';
$lang['event_help_contentprecompile'] = '<p>Odeslána před předáním obsahu ke zpracování pomocí Smarty.</p>
<h4>Parametry/h4>
<ul>
<li>\'content\' - Odkaz na ovlivněný text obsahu.</li>
</ul>';
$lang['event_help_contentstylesheet'] = '<p>Odeslána před předáním stylu prohlížeči.</p>
<h4>Parametry</h4>
<ul>
<li>\'content\' - Odkaz na ovlivněný text stylu.</li>
</ul>';
$lang['event_help_deleteglobalcontentpost'] = '<p>Odeslána po smazání obsahového bloku ze systému.</p>
<h4>Parametry</h4>
<ul>
<li>\'global_content\' - Odkaz na ovlivněný objekt obsahového bloku.</li>
</ul>';
$lang['event_help_deleteglobalcontentpre'] = '<p>Odeslána před smazáním obsahového bloku ze systému.</p>
<h4>Parametry</h4>
<ul>
<li>\'global_content\' - Odkaz na ovlivněný objekt obsahového bloku.</li>
</ul>';
$lang['event_help_deletegrouppost'] = '<p>Odeslána po vymazání skupiny ze systému.</p>
<h4>Parametry</h4>
<ul>
<li>\'group\' - Odkaz na ovlivněný objekt skupiny.</li>
</ul>';
$lang['event_help_deletegrouppre'] = '<p>Odeslána před vymazáním skupiny ze systému.</p>
<h4>Parametry</h4>
<ul>
<li>\'group\' - Odkaz na ovlivněný objekt skupiny.</li>
</ul>';
$lang['event_help_deletestylesheetpost'] = '<p>Odeslána po vymazání stylu ze systému.</p>
<h4>Parametry</h4>
<ul>
<li>\'stylesheet\' - Odkaz na ovlivněný objekt stylu.</li>
</ul>';
$lang['event_help_deletestylesheetpre'] = '<p>Odeslána před vymazáním stylu ze systému.</p>
<h4>Parametry</h4>
<ul>
<li>\'stylesheet\' - Odkaz na ovlivněný objekt stylu.</li>
</ul>';
$lang['event_help_deletetemplatepost'] = '<p>Odeslána po vymazání šablony ze systému.</p>
<h4>Parametry</h4>
<ul>
<li>\'template\' - Odkaz na ovlivněný objekt šablony.</li>
</ul>';
$lang['event_help_deletetemplatepre'] = '<p>Odeslána před vymazáním šablony ze systému.</p>
<h4>Parametry</h4>
<ul>
<li>\'template\' - Odkaz na ovlivněný objekt šablony.</li>
</ul>';
$lang['event_help_deleteuserdefinedtagpost'] = '<p>Odesláno po smazání uživatelského tagu.</p>';
$lang['event_help_deleteuserdefinedtagpre'] = '<p>Odesláno před smazáním uživatelského tagu.</p>';
$lang['event_help_deleteuserpost'] = '<p>Odeslána po vymazání uživatele ze systému.</p>
<h4>Parametry</h4>
<ul>
<li>\'user\' - Odkaz na ovlivněný uživatelský objekt.</li>
</ul>';
$lang['event_help_deleteuserpre'] = '<p>Odeslána před vymazáním uživatele ze systému.</p>
<h4>Parametry</h4>
<ul>
<li>\'user\' - Odkaz na ovlivněný uživatelský objekt.</li>
</ul>';
$lang['event_help_editglobalcontentpost'] = '<p>Odeslána před uložením změn obsahového bloku.</p>
<h4>Parametry</h4>
<ul>
<li>\'global_content\' - Odkaz na ovlivněný objekt tobsahového bloku.</li>
</ul>';
$lang['event_help_editglobalcontentpre'] = '<p>Odeslána před uložením změn obsahového bloku.</p>
<h4>Parametry</h4>
<ul>
<li>\'global_content\' - Odkaz na ovlivněný objekt obsahového bloku.</li>
</ul>';
$lang['event_help_editgrouppost'] = '<p>Odeslána po uložení změn vlastností skupiny.</p>
<h4>Parametry</h4>
<ul>
<li>\'group\' - Odkaz na ovlivněný objekt skupiny.</li>
</ul>';
$lang['event_help_editgrouppre'] = '<p>Odeslána před uložením změny vlastností skupiny.</p>
<h4>Parametry</h4>
<ul>
<li>\'group\' - Odkaz na ovlivněný objekt skupiny.</li>
</ul>';
$lang['event_help_editstylesheetpost'] = '<p>Odeslána po uložení změn stylu.</p>
<h4>Parametry</h4>
<ul>
<li>\'stylesheet\' - Odkaz na ovlivněný objekt stylu.</li>
</ul>';
$lang['event_help_editstylesheetpre'] = '<p>Odeslána před uložením změn stylu.</p>
<h4>Parametry</h4>
<ul>
<li>\'stylesheet\' - Odkaz na ovlivněný objekt stylu.</li>
</ul>';
$lang['event_help_edittemplatepost'] = '<p>Odeslána po uložení změn v šabloně.</p>
<h4>Parametry</h4>
<ul>
<li>\'template\' - Odkaz na ovlivněný objekt šablony.</li>
</ul>';
$lang['event_help_edittemplatepre'] = '<p>Odeslána před uložením změn v šabloně.</p>
<h4>Parametry</h4>
<ul>
<li>\'template\' - Odkaz na ovlivněný objekt šablony.</li>
</ul>';
$lang['event_help_edituserdefinedtagpost'] = '<p>Odesláno po aktualizaci uživatelského tagu.</p>';
$lang['event_help_edituserdefinedtagpre'] = '<p>Odesláno před aktualizací uživatelského tagu.</p>';
$lang['event_help_edituserpost'] = '<p>Odeslána po uložení změn vlastností uživatele.</p>
<h4>Parametry</h4>
<ul>
<li>\'user\' - Odkaz na ovlivněný uživatelský objekt.</li>
</ul>';
$lang['event_help_edituserpre'] = '<p>Odeslána před uložením změn vlastností uživatele.</p>
<h4>Parametry</h4>
<ul>
<li>\'user\' - Odkaz na ovlivněný uživatelský objekt.</li>
</ul>';
$lang['event_help_globalcontentpostcompile'] = '<p>Odeslána po zpracování obsahového bloku pomocí Smarty.</p>
<h4>Parametry</h4>
<ul>
<li>\'global_content\' - Odkaz na ovlivněný text obsahového bloku.</li>
</ul>';
$lang['event_help_globalcontentprecompile'] = '<p>Odeslána před předáním obsahového bloku ke zpracování pomocí Smarty.</p>
<h4>Parametry</h4>
<ul>
<li>\'global_content\' - Odkaz na ovlivněný text obsahového bloku.</li>
</ul>';
$lang['event_help_loginpost'] = '<p>Odeslána po přihlášeni uživatele do administračního panelu.</p>
<h4>Parametry</h4>
<ul>
<li>\'user\' - Odkaz na ovlivněný uživatelský objekt.</li>
</ul>';
$lang['event_help_logoutpost'] = '<p>Odeslána po odhlášeni uživatele z administračního panelu.</p>
<h4>Parametry</h4>
<ul>
<li>\'user\' - Odkaz na ovlivněný uživatelský objekt.</li>
</ul>';
$lang['event_help_moduleinstalled'] = '<p>Odesláno po instalaci modulu.</p>';
$lang['event_help_moduleuninstalled'] = '<p>Odesláno po odinstalaci modulu.</p>';
$lang['event_help_moduleupgraded'] = '<p>Odesláno po aktualizaci modulu.</p>';
$lang['event_help_smartypostcompile'] = '<p>Odeslána po zpracování jakéhokoliv obsahu pomocí Smarty.</p>
<h4>Parametry</h4>
<ul>
<li>\'content\' - Odkaz na ovlivněný text.</li>
</ul>';
$lang['event_help_smartyprecompile'] = '<p>Odeslána před předáním jakéhokoliv obsahu ke zpracování pomocí Smarty.</p>
<h4>Parametry</h4>
<ul>
<li>\'content\' - Odkaz na ovlivněný text.</li>
</ul>';
$lang['event_help_templatepostcompile'] = '<p>Odeslána po zpracování šablony pomocí Smarty.</p>
<h4>Parametry</h4>
<ul>
<li>\'template\' - Odkaz na ovlivněný text šablony.</li>
</ul>';
$lang['event_help_templateprecompile'] = '<p>Odeslána před předáním šablony ke zpracování pomocí Smarty.</p>
<h4>Parametry</h4>
<ul>
<li>\'template\' - Odkaz na ovlivněný text šablony.</li>
</ul>';
$lang['event_name'] = 'Jméno události';
$lang['execute'] = 'Spouštění';
$lang['expand'] = 'Rozbalit sekci';
$lang['expandall'] = 'Rozbalit všechny sekce';
$lang['export'] = 'Exportovat';
$lang['extensions'] = 'Rozšíření';
$lang['extensionsdescription'] = 'Moduly, tagy a další rozmanité položky.';
$lang['extra1'] = 'Extra atribut stránky 1';
$lang['extra2'] = 'Extra atribut stránky 2';
$lang['extra3'] = 'Extra atribut stránky 3';
$lang['E_DEPRECATED'] = 'Je E_DEPRECATED zakázáno v error_reporting';
$lang['E_STRICT'] = 'Je E_STRICT zakázáno v error_reporting';
$lang['failure'] = 'Chyba';
$lang['false'] = 'NE';
$lang['filecreatedirnoname'] = 'Nelze vytvořit adresář bez jména.';
$lang['filemanagement'] = 'Správa souborů';
$lang['filemanager'] = 'Správce souborů';
$lang['filemanagerdescription'] = 'Nahrát a spravovat soubory.';
$lang['filename'] = 'Jméno souboru';
$lang['filenotuploaded'] = 'Soubor nemůže být přenesen. Chyba práv nebo problém se Safe mode?';
$lang['files'] = 'Soubory';
$lang['filesize'] = 'Velikost';
$lang['files_checksum_failed'] = 'Kontrolní součet souborů nemůže být zkontrolován';
$lang['files_failed'] = 'Soubory nevyhovují kontrolnímu součtu md5sum';
$lang['files_not_found'] = 'Soubory nebyly nalezeny';
$lang['file_get_contents'] = 'Testovat file_get_contents';
$lang['file_uploads'] = 'Nahrávání souborů';
$lang['file_url'] = 'Odkaz na soubor (místo URL)';
$lang['filter'] = 'Filtr';
$lang['filterbymodule'] = 'Třídit podle modulů';
$lang['first'] = 'První';
$lang['firstname'] = 'Jméno';
$lang['forgotpwprompt'] = 'Vložte uživatelské jméno administrátora. Na emailovou adresu asociovanou s tímto jménem budou zaslány nové přihlašovací údaje';
$lang['forums'] = 'Fóra';
$lang['frontendlang'] = 'Výchozí jazyk pro rozhraní';
$lang['frontendwysiwygtouse'] = 'Wysiwyg na stránkách (pro koncové uživatele)';
$lang['gcb_wysiwyg'] = 'Povolit GCB WYSIWYG';
$lang['gcb_wysiwyg_help'] = 'Povolit WYSIWYG editor při editaci Global Content Blocks';
$lang['gd_version'] = 'Verze GD';
$lang['general_settings'] = 'Hlavní nastavení';
$lang['globalconfig'] = 'Globální nastavení';
$lang['globalmetadata'] = 'Globální Metadata';
$lang['global_umask'] = 'Maska pro vytváření souborů (umask)';
$lang['group'] = 'Skupina';
$lang['groupassignmentdescription'] = 'Zde se zařazují uživatelé do skupin.';
$lang['groupassignments'] = 'Přiřazení do skupiny';
$lang['groupmanagement'] = 'Správa skupin';
$lang['groupname'] = 'Jméno skupiny';
$lang['grouppermissions'] = 'Oprávnění skupiny';
$lang['groupperms'] = 'Oprávnění skupiny';
$lang['grouppermsdescription'] = 'Nastavení oprávnění a úroveň práv skupin';
$lang['groups'] = 'Skupiny';
$lang['groupsdescription'] = 'Zde se upravují uživatelské skupiny.';
$lang['handler'] = 'Handler (uživatelský tag)';
$lang['handle_404'] = 'Vlastní 404 manipulace';
$lang['hasdependents'] = 'Má závislosti';
$lang['headtags'] = 'Head Tagy';
$lang['help'] = 'Nápověda';
$lang['helpaddtemplate'] = '<p>Šablona je to, co ovládá vzhled stránek.</p><p>Vytvořte zde svůj layout a vložte také svůj CSS do sekce šablon pro vlastní vzhled Vašich elementů na stránkách.</p>';
$lang['helplisttemplate'] = '<p>Tato stránka umožňuje upravovat, mazat a vytvářet šablony.</p><p>Pro vytvoření nové šablony, klikněte na tlačítko <u>Vložit novou šablonu</u>.</p><p>Pokud si přejete nastavit veškeré stránky pro používání stejné šablony, klikněte na odkaz <u>Nastavit všechny stránky</u>.</p><p>Pokud chcete duplikovat šablonu, klikněte na ikonu <u>Kopírovat</u> a budete tázán na pojmenování nové šablony.</p>';
$lang['helpwithsection'] = '%s nápověda';
$lang['help_systeminformation'] = 'Informace zobrazené níže pocházejí z mnoha zdrojů. Na jejich základě můžete lépe přijít na příčinu problémů s instalací CMSMS, případně lépe informovat ty, kteří by vám mohli pomoci (např. ve fóru CMSMS)';
$lang['hidefrommenu'] = 'Skrýt z menu';
$lang['hide_help_links'] = 'Skrýt odkazy nápovědy';
$lang['hide_help_links_help'] = 'Zaškrtnutím tohoto pole zakážete zobrazovaní odkazů nápovědy wiki a modulů v hlavičkách stránek.';
$lang['home'] = 'Domů';
$lang['homepage'] = 'Domovská stránka';
$lang['hostname'] = 'Hostitel';
$lang['hour'] = 'hodina';
$lang['hours'] = 'hodin';
$lang['idnotvalid'] = 'Zadané id je neplatné';
$lang['ignorenotificationsfrommodules'] = 'Ignorovat upozornění z těchto modulů';
$lang['illegalcharacters'] = 'Nesprávné znaky v poli %s.';
$lang['image'] = 'Obrázek';
$lang['inactive'] = 'Neaktivní';
$lang['indent'] = 'Odsadit výpis stránek pro zvýraznění hierarchie';
$lang['informationmissing'] = 'Informace chybí';
$lang['info_autoalias'] = 'Pokud je toto pole prázdné, alias bude vytvořen automaticky.';
$lang['info_deletepages'] = 'Poznámka: kvůli omezeným oprávněním nejsou některé stránky vybrané ke smazání níže uvedeny';
$lang['info_edeprecated_failed'] = 'Při povoleném E_DEPRECATED v hlášení chyb uvidí uživatelé mnoho varování, což může ovlivnit zobrazení a funkcionalitu';
$lang['info_edituser_password'] = 'Změnit toto pole pro změnu uživatelského hesla';
$lang['info_edituser_passwordagain'] = 'Změnit toto pole pro změnu uživatelského hesla';
$lang['info_estrict_failed'] = 'Některé knihovny používané CMSMS nepracují správně s E_STRICT.  Prosím zakažte to před pokračováním';
$lang['info_generate_cksum_file'] = 'Tato funkce slouží ke generování kontrolního součtu a jeho uložení na Váš počítač pro pozdější kontrolu. Ta by měla být provedena bezprostředně před spuštěním stránek, po aktualizacích a podstatných změnách.';
$lang['info_pagealias'] = 'Zadejte unikátní alias pro tuto stránku.';
$lang['info_preview_notice'] = 'Varování: Tento náhledový panel se chová více jako okno prohlížeče a umožňuje navigaci z původně prohlížené stránky. Pokud tak uděláte, může nastat nepředvídané chování. Pokud v náhledu odejdete na jinou stránku a poté se vrátíte, neuvidíte neodeslané změny dokud neprovedete změny obsahu v hlavní záložce a poté neobnovíte tuto záložku. Pokud odejdete na jinou stránku během přidávání obsahu, nelze se navrátit a je třeba obnovit tento panel.';
$lang['info_sitedownexcludes'] = 'Tento parametr dovoluje výpis čárkou oddělených ip adres nebo sítí, které mají být vyřazeny z mechanizmu mimo provoz. To dovoluje administrátorům pracovat na stránkách, ale anonymní návštěvníci obdrží zprávu mimo provoz.<br/><br/>Adresy mohou být zadány v následujících formátech:<br/>
1. xxx.xxx.xxx.xxx -- (přesná IP adresa)<br/>
2. xxx.xxx.xxx.[yyy-zzz] -- (rozsah IP adres)<br/>
3. xxx.xxx.xxx.xxx/nn -- (nn = počet bitů, styl cisco.  např.:  192.168.0.100/24 = celý subnet 192.168.0 třídy C)';
$lang['info_target'] = 'Tato volba může být použita Správcem menu pro uvedení kdy a jak mají být otevřeny nové rámce nebo okna. Některé šablony správce menu tuto volbu ignorují.';
$lang['info_validation'] = 'Tato funkce porovná kontrolní součty nalezené v nahraném souboru se soubory v současné instalaci. Může pomoci se zjištěním problémů při nahrávání, nebo při zjišťování, které soubory byly pozměněny, pokud byla Vaše stránka hacknuta. Soubor s kontrolním součtem je generován pro každou verzi CMS Made Simple od verze 1.4';
$lang['insecure'] = 'Nezabezpečené (HTTP)';
$lang['installed'] = 'Instalováno';
$lang['installed_modules'] = 'Nainstalované moduly';
$lang['invalid'] = 'Neplatný';
$lang['invalidcode'] = 'Vložen nesprávný kód.';
$lang['invalidcode_brace_missing'] = 'Nesprávný počet závorek';
$lang['invalidemail'] = 'Vložená emailová adresa je neplatná';
$lang['invalidparent'] = 'Je třeba vybrat rodičovskou stránku (kontaktujte administrátora pokud nevidíte tuto volbu).';
$lang['invalid_test'] = 'Chybná hodnota test param!';
$lang['ip_addr'] = 'IP adresa';
$lang['itemid'] = 'ID položky';
$lang['itemname'] = 'Jméno položky';
$lang['itsbeensincelogin'] = 'Je to %s od Vašeho posledního přihlášení';
$lang['jsdisabled'] = 'Omlouváme se, ale tato funkce potřebuje povolení javascript.';
$lang['language'] = 'Jazyk';
$lang['last'] = 'Poslední';
$lang['lastname'] = 'Příjmení';
$lang['last_modified_at'] = 'Naposledy upraveno';
$lang['last_modified_by'] = 'Naposledy upravil';
$lang['layout'] = 'Vzhled';
$lang['layoutdescription'] = 'Volby vzhledu stránek.';
$lang['loginprompt'] = 'Vložte správné uživatelské údaje pro přístup do administračního panelu.';
$lang['logintitle'] = 'CMS Made Simple přihlášení do administrace';
$lang['login_info'] = 'Pro správnou funkci administrátorské konzole';
$lang['login_info_params'] = '<ol> 
  <li>Cookies povoleny ve Vašem prohlížeči</li> 
  <li>Javascript povolený ve Vašem prohlížeči</li> 
  <li>Popup okna aktivní pro následující adresy:</li> 
</ol>';
$lang['login_info_title'] = 'Informace';
$lang['logout'] = 'Odhlásit';
$lang['lostpw'] = 'Zapomněli jste své heslo?';
$lang['lostpwemail'] = 'Byl Vám doručen tento email, protože bylo zažádáno o změnu (%s) hesla pro uživatelský účet (%s).  Pokud chcete resetovat heslo k tomuto účtu, klikněte na odkaz níže nebo vložte toto do adresního řádku Vašeho oblíbeného prohlížeče:
%s

Pokud se domníváte, že tento požadavek je nesprávný nebo vykonán chybně, jednoduše tento email ignorujte a nic nebude změněno.';
$lang['lostpwemailsubject'] = '[%s] obnova hesla';
$lang['magic_quotes_gpc'] = 'Magic quotes pro Get/Post/Cookie';
$lang['magic_quotes_gpc_on'] = 'Jednoduché uvozovky, dvojité uvozovky a zpětná lomítka jsou eskapována automaticky. Můžete mít problém při ukládání šablon';
$lang['magic_quotes_runtime'] = 'Magic quotes v runtime';
$lang['magic_quotes_runtime_on'] = 'Většina funkcí vracející data bude mít uvozovky eskapovány zpětným lomítkem. Můžete s tím mít problémy';
$lang['main'] = 'Hlavní';
$lang['mainmenu'] = 'Hlavní menu';
$lang['managebookmarks'] = 'Spravovat záložky';
$lang['managebookmarksdescription'] = 'Zde můžete spravovat Vaše administrační záložky.';
$lang['master_admintheme'] = 'Výchozí téma administračního rozhraní (pro přihlašovací stránku a nového uživatele)';
$lang['maximumversion'] = 'Maximální verze';
$lang['maximumversionsupported'] = 'Maximální CMSMS verze podporována';
$lang['max_execution_time'] = 'Maximální doba provádění';
$lang['md5_function'] = 'md5 funkce';
$lang['memory_limit'] = 'Paměťový limit v PHP';
$lang['menutext'] = 'Text menu';
$lang['minimumversion'] = 'Minimální verze';
$lang['minimumversionrequired'] = 'Minimální CMSMS verze nutná';
$lang['minute'] = 'minuta';
$lang['minutes'] = 'minuty';
$lang['missingdependency'] = 'Nevyřešené závislosti';
$lang['missingparams'] = 'Některé parametry chyběly nebo byly nesprávné';
$lang['modifygroupassignments'] = 'Upravit přiřazení skupiny';
$lang['module'] = 'Moduly';
$lang['moduleabout'] = 'O modulu %s';
$lang['moduledescription'] = 'Moduly rozšiřují CMS Made Simple o možnost uživatelských funkcí.';
$lang['moduleerrormessage'] = 'Chybové hlášení pro modul %s';
$lang['modulehelp'] = 'Nápověda pro modul %s';
$lang['moduleinstalled'] = 'Modul je již instalován';
$lang['moduleinstallmessage'] = 'Instalační zpráva pro modul %s';
$lang['moduleinterface'] = '%s rozhraní';
$lang['modules'] = 'Moduly';
$lang['modulesnotwritable'] = 'Do adresáře modulů nelze zapisovat, pokud byste rádi instalovali moduly pomocí XML souborů, musíte tomuto adresáři nastavit plná čtení/zápis/spouštění práva (chmod 777). Toto může být ovlivněno také safe mode.';
$lang['moduleuninstallmessage'] = 'Odinstalační zpráva pro modul %s';
$lang['moduleupgraded'] = 'Upgrade Successfull';
$lang['moduleupgradeerror'] = 'Nastala chyba při upgradu modulu.';
$lang['module_help'] = 'Nápověda modulu';
$lang['module_name'] = 'Jméno modulu';
$lang['move'] = 'Přesunout';
$lang['movecontent'] = 'Přesunout stránky';
$lang['myaccount'] = 'Můj účet';
$lang['myaccountdescription'] = 'Zde můžete upravit údaje svého osobního účtu.';
$lang['myprefs'] = 'Má nastavení';
$lang['myprefsdescription'] = 'Zde si můžete upravit administrační část podle svého.';
$lang['name'] = 'Uživatelské jméno';
$lang['needpermissionto'] = 'Potřebujete \\\'%s\\\' práva pro vykonání této funkce.';
$lang['new_window'] = 'nové okno';
$lang['next'] = 'Další';
$lang['no'] = 'Ne';
$lang['noaccessto'] = 'Bez přístupu k %s';
$lang['nodefault'] = 'Výchozí není vybrán';
$lang['noentries'] = 'Žádné položky';
$lang['nofieldgiven'] = 'Nezadán žádný %s!';
$lang['nofiles'] = 'Žádné soubory';
$lang['noncachable'] = 'Nelze kešovat';
$lang['none'] = 'Žádné';
$lang['nopaging'] = 'Zobrazit všechny položky';
$lang['nopasswordforrecovery'] = 'Tento uživatel nemá nastavenou emailovou adresu. Obnova hesla není možná. Kontaktujte prosím administrátora.';
$lang['nopasswordmatch'] = 'Hesla se neshodují';
$lang['norealdirectory'] = 'Nezadán správný adresář';
$lang['norealfile'] = 'Nebyl zadán existující soubor';
$lang['notifications'] = 'Upozornění';
$lang['notinstalled'] = 'Nenainstalován';
$lang['no_bulk_performed'] = 'Operace neprovedena.';
$lang['no_file_url'] = 'Nic (Použít URL výše)';
$lang['no_permission'] = 'Nemáte oprávnění pro vykonání této funkce.';
$lang['of'] = 'z';
$lang['off'] = 'Vyp';
$lang['on'] = 'Zap';
$lang['open_basedir_active'] = 'Nekontrolováno, protože je aktivní open_basedir';
$lang['options'] = 'Volby';
$lang['order'] = 'Seřadit';
$lang['order_too_large'] = 'Pořadí stránky nesmí být větší než počet stránek v této úrovni. Stránky nebyly setříděny.';
$lang['order_too_small'] = 'Pořadí stránky nesmí být nula. Stránky nebyly setříděny.';
$lang['originator'] = 'Původce';
$lang['os_session_save_path'] = 'Nekontrolováno kvůli OS cestě';
$lang['other'] = 'Jiné';
$lang['output'] = 'Výstup';
$lang['owner'] = 'Vlastník';
$lang['page'] = 'Stránka';
$lang['pagealias'] = 'Alias stránky';
$lang['pagedata_codeblock'] = 'Data SMARTY nebo logika, příslušná dané stránce';
$lang['pagedefaults'] = 'Výchozí hodnoty stránky';
$lang['pagedefaultsdescription'] = 'Nastavit výchozí hodnoty pro nové stránky';
$lang['pagelink_circular'] = 'Odkaz na stránku nemůže mít jiný odkaz jako svůj cíl';
$lang['pages'] = 'Stránky';
$lang['pagesdescription'] = 'Zde se přidávají a upravují stránky a jiný obsah.';
$lang['pages_reordered'] = 'Stránky byly úspěšně setříděny';
$lang['page_metadata'] = 'Metadata specifická pro stránku';
$lang['page_reordered'] = 'Stránka byla úspěšně setříděna.';
$lang['page_url'] = 'URL stránky';
$lang['parameters'] = 'Parametry';
$lang['parent'] = 'Nadřazený';
$lang['password'] = 'Heslo';
$lang['passwordagain'] = 'Heslo (znovu)';
$lang['passwordchange'] = 'Zadejte prosím nové heslo';
$lang['passwordchangedlogin'] = 'Heslo změněno. Přihlašte se prosím s novými údaji.';
$lang['perform_validation'] = 'Provést ověření';
$lang['permission'] = 'Oprávnění';
$lang['permissions'] = 'Oprávnění';
$lang['permissionschanged'] = 'Oprávnění byla aktualizována.';
$lang['permission_information'] = 'Informace o oprávněních';
$lang['phpversion'] = 'Současná verze PHP';
$lang['php_information'] = 'Informace PHP';
$lang['pluginabout'] = 'O %s tagu';
$lang['pluginhelp'] = 'Nápověda pro %s tag';
$lang['pluginmanagement'] = 'Správa pluginů';
$lang['plugins'] = 'Pluginy';
$lang['post_max_size'] = 'Maximální veilkost dat zasílaných metodou POST (Maximum post size)';
$lang['preferences'] = 'Nastavení';
$lang['preferencesdescription'] = 'Zde se upravují různá nastavení prezentace.';
$lang['prefsupdated'] = 'Nastavení upraveno.';
$lang['preview'] = 'Náhled';
$lang['previewdescription'] = 'Náhled změn';
$lang['previous'] = 'Předchozí';
$lang['pseudocron_granularity'] = 'Interval pseudocronu';
$lang['read'] = 'Čtení';
$lang['recentpages'] = 'Nedávné stránky';
$lang['recoveryemailsent'] = 'Email zaslán na uloženou adresu. Zkontrolujte svoji schránku pro další instrukce.';
$lang['remote_connection_timeout'] = 'Připojení vypšelo!';
$lang['remote_response_404'] = 'Vzdálená odpověď: nenalezeno!';
$lang['remote_response_error'] = 'Vzdálená odpověď: chyba!';
$lang['remote_response_ok'] = 'Vzdálená odpověď: ok!';
$lang['remove'] = 'Odstranit';
$lang['reorder'] = 'Setřídit';
$lang['reorderpages'] = 'Setřídit stránky';
$lang['results'] = 'Výsledky';
$lang['revert'] = 'Vrátit všechny změny';
$lang['root'] = 'Kořen';
$lang['run'] = 'Spustit';
$lang['runuserplugin'] = 'Spustit uživatelský plugin';
$lang['run_udt'] = 'Spustit tento uživatelsky definovaný tag';
$lang['safe_mode'] = 'Safe_mode v PHP';
$lang['saveconfig'] = 'Uložit nastavení';
$lang['searchable'] = 'Tato stránka je prohledávatelná';
$lang['search_string_find'] = 'Připojení v pořádku!';
$lang['secure'] = 'Zabezpečené (HTTPS)';
$lang['secure_page'] = 'Použít HTTPS pro tuto stránku';
$lang['selectall'] = 'Vybrat vše';
$lang['selecteditems'] = 'Vybrané položky';
$lang['selectgroup'] = 'Vybrat skupinu';
$lang['send'] = 'Odeslat';
$lang['server_api'] = 'API serveru';
$lang['server_cache_settings'] = 'Nastavení keše serveru';
$lang['server_db_type'] = 'Databázový server';
$lang['server_db_version'] = 'Verze databázového serveru';
$lang['server_information'] = 'Informace serveru';
$lang['server_os'] = 'Operační systém serveru';
$lang['server_software'] = 'Software serveru';
$lang['session_save_path'] = 'Cesta k úložišti sessions (sessions save path)';
$lang['session_use_cookies'] = 'Session smí používat cookies';
$lang['setfalse'] = 'Nastavit NE';
$lang['settemplate'] = 'Nastavit šablonu';
$lang['settrue'] = 'Nastavit ano';
$lang['setup'] = 'Pokročilá nastavení';
$lang['showall'] = 'Zobrazit vše';
$lang['showbookmarks'] = 'Ukázat administrační záložky';
$lang['showinmenu'] = 'Ukázat v menu';
$lang['showrecent'] = 'Ukázat nejčastěji používané stránky';
$lang['showsite'] = 'Ukázat prezentaci';
$lang['sibling_duplicate_order'] = 'Dvě sourozenecké stránky nemohou mít to samé pořadí. Stránky nebyly setříděny.';
$lang['siteadmin'] = 'Administrace stránek';
$lang['sitedownexcludeadmins'] = 'Vyloučit uživatele přihlášené do CMSMS administrační konzole';
$lang['sitedownexcludes'] = 'Vyjmout tyto adresy z hlášení mimo provoz';
$lang['sitedownmessage'] = 'Zpráva stránky mimo provoz';
$lang['sitedownwarning'] = '<strong>Varování:</strong> Vaše stránky momentálně zobrazují zprávu "Stránky mimo provoz z důvodu údržby".  Pro vyřešení odstraňte soubor %s.';
$lang['sitedown_settings'] = 'Nastavení zpráv mimo provoz';
$lang['sitename'] = 'Jméno stránek';
$lang['siteprefs'] = 'Předvolby prezentace';
$lang['sqlerror'] = 'Chyba SQL v %s';
$lang['start_upgrade_process'] = 'Zahájit aktualizaci';
$lang['status'] = 'Stav';
$lang['subitems'] = 'Obsahuje';
$lang['submit'] = 'Odeslat';
$lang['submitdescription'] = 'Uložit změny';
$lang['success'] = 'Úspěch';
$lang['syntaxhighlightertouse'] = 'Vyberte zvýrazňování syntaxe';
$lang['systeminfo'] = 'Informace o systému';
$lang['systeminfodescription'] = 'Zobrazí různé informace o systému, které mohou být užitečné při zjišťování problémů.';
$lang['systeminfo_copy_paste'] = 'Prosím zkopírujte tyto informace a vložte je do svého dotazu ve fóru';
$lang['system_verification'] = 'Ověření systému';
$lang['tabindex'] = 'Záložkové menu';
$lang['tagdescription'] = 'Tagy jsou drobné funkce, které mohou být do obsahu a/nebo šablon.';
$lang['tags'] = 'Tagy';
$lang['tagtousegcb'] = 'Tag pro použití tohoto bloku';
$lang['target'] = 'Cíl';
$lang['tempnam_function'] = 'funkce temnap';
$lang['test'] = 'Zkouška';
$lang['test_allow_url_fopen_failed'] = 'Pokud je vypnuta direktiva allow url fopen, nebudete moci přistupovat k objektům URL pomocí HTTP nebo FTP protokolu.';
$lang['test_check_open_basedir_failed'] = 'Na serveru jsou nastavena open_basedir omezení. Některá rozšíření nemusí fungovat správně. V případě potřeby se prosím obraťte na správce serveru.';
$lang['test_edeprecated_failed'] = 'E_DEPRECATED je povoleno';
$lang['test_estrict_failed'] = 'E_STRICT je povoleno v error_reporting';
$lang['test_remote_url'] = 'Test pro vzdálenou URL';
$lang['test_remote_url_failed'] = 'Pravděpodobně nebudete moci otevřít soubor na vzdáleném webovém serveru.';
$lang['text_settemplate'] = 'Nastavit vybrané stránky na jinou šablonu';
$lang['thumbnail'] = 'Náhled';
$lang['thumbnail_height'] = 'Výška náhledu';
$lang['thumbnail_width'] = 'Šířka náhledu';
$lang['title'] = 'Název';
$lang['titleattribute'] = 'Popisek (atribut titulku)';
$lang['tools'] = 'Nástroje';
$lang['troubleshooting'] = '(Řešení problémů)';
$lang['true'] = 'ANO';
$lang['type'] = 'Typ';
$lang['typenotvalid'] = 'Typ není platný';
$lang['unknown'] = 'Neznámé';
$lang['unlimited'] = 'Neomezený';
$lang['untested'] = 'Netestováno';
$lang['up'] = 'Nahoru';
$lang['updateperm'] = 'Aktualizovat oprávnění';
$lang['upload_cksum_file'] = 'Nahrát soubor s kontrolním součtem';
$lang['upload_max_filesize'] = 'Maximální velikost nahrávaného souboru (Maximum upload size)';
$lang['user'] = 'Uživatel';
$lang['userdefinedtags'] = 'Uživatelské tagy';
$lang['usermanagement'] = 'Správa uživatelů';
$lang['username'] = 'Uživatelské jméno';
$lang['usernameincorrect'] = 'uživatelské jméno nebo heslo neplatné';
$lang['usernotfound'] = 'Uživatel nenalezen.';
$lang['userprefs'] = 'Nastavení uživatele';
$lang['users'] = 'Uživatelé';
$lang['usersassignedtogroup'] = 'Uživatel přiřazen ke skupině %s';
$lang['usersdescription'] = 'Zde se upravují uživatelé';
$lang['usersgroups'] = 'Uživatelé/Skupiny';
$lang['usersgroupsdescription'] = 'Nastavení uživatelů a skupin.';
$lang['usertagadded'] = 'Uživatelský tag byl úspěšně přidán.';
$lang['usertagdeleted'] = 'Uživatelský tag byl úspěšně odstraněn.';
$lang['usertagdescription'] = 'Tagy které můžete vytvářet a upravovat sami pro provedení určitých činností, přímo z vašeho prohlížeče.';
$lang['usertagexists'] = 'Tag tohoto jména existuje. Zvolte prosím jiné.';
$lang['usertags'] = 'Uživatelské tagy';
$lang['usertagupdated'] = 'Uživatelský tag byl úspěšně aktualizován.';
$lang['user_created'] = 'Vlastní záložky';
$lang['user_tag'] = 'Uživatelský Tag';
$lang['usewysiwyg'] = 'Používat WYSIWYG editor pro obsah';
$lang['use_wysiwyg'] = 'Použít WYSIWYG';
$lang['version'] = 'Verze';
$lang['view'] = 'Zobrazit';
$lang['viewsite'] = 'Zobrazit prezentaci';
$lang['view_page'] = 'Prohlédnout tuto stránku v novém okně';
$lang['warning_mail_settings'] = 'Nenastavili jste volby, potřebné pro odesílání e-mailů.  Pokud potřebujete odesílat e-maily, jděte na stránku <a href="%s">Rozšíření >> CMSMailer modul</a> a nastavte volby podle údajů poskytnutých vaším hostingem.';
$lang['warning_safe_mode'] = '<strong><em>VAROVÁNÍ:</em></strong> PHP Safe mód je povolen.  Toto způsobí potíže s uploadem souborů přes rozhraní webového prohlížeče, včetně obrázků, témat a balíčků XML modulů.  Pro zakázání safe módu bude třeba kontaktovat Vašeho hostingového správce.';
$lang['warning_upgrade'] = '<em><strong>Varování:</strong></em> CMSMS je třeba aktualizovat.';
$lang['warning_upgrade_info1'] = 'Nyní používáte databázové schéma %s. a musíte aktualizovat na schéma %s';
$lang['warning_upgrade_info2'] = 'Prosím klikněte na následující odkaz: %s.';
$lang['welcomemsg'] = 'Vítejte %s';
$lang['welcome_user'] = 'Vítejte';
$lang['wontdeletetemplateinuse'] = 'Tyto šablony jsou používány a nebudou smazány';
$lang['write'] = 'Zápis';
$lang['wysiwygtouse'] = 'Vyberte WYSIWYG editor';
$lang['xml_function'] = 'Základní XML (expat) podpora';
$lang['yes'] = 'Ano';
$lang['your_ipaddress'] = 'Vaše IP adresa je';
$lang['dependencies'] = 'Závislosti';
$lang['help_css_max_age'] = 'Tento parametr by měl být nastaven relativně vysoko pro statické stránky a na 0 pro vývoj stránek';
$lang['help_page_alias'] = 'Alias je použit jako alternativa k id stránky pro jedinečnou identifikaci stránky. Musí být jedinečný přes všechny stránky. Alias je také používán při vytváření URL stránky';
$lang['help_page_cachable'] = 'Při nastavení co největšího možného počtu stránek jako kešovatelných může být zvýšen výkon. Toto ale nemůže být použito u stránek, kde se mění obsah na základě dotazů';
$lang['help_page_searchable'] = 'Toto nastavení uvádí, zda může být obsah této stránky indexován modulem Vyhledávání';
$lang['help_page_url'] = 'Zadejte alternativní URL (relativní ke kořenu Vaší prezentace), která může být použita pro jedinečnou identifikaci této stránky. např. cesta/k/me_strance. URL stránky je užitečné při povolených pěkných url.';
$lang['addtemplate'] = 'Vložit novou šablonu';
$lang['deletetemplate'] = 'Smazat styly';
$lang['deletetemplates'] = 'Smazat šablony';
$lang['edittemplate'] = 'Upravit šablonu';
$lang['edittemplatesuccess'] = 'Šablona aktualizována';
$lang['template'] = 'Šablona';
$lang['templateexists'] = 'Jméno šablony již existuje';
$lang['templates'] = 'Šablony';
$lang['ga'] = 'GA1.2.637185787.1618486234';
$lang['gid'] = 'GA1.2.1988218282.1619418360';
?>