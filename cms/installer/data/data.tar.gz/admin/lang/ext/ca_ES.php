<?php
$lang['403description'] = 'Pàgina prohibida';
$lang['404description'] = 'Pàgina no trobada';
$lang['aa_main_tab__'] = 'Principal';
$lang['about'] = 'Sobre';
$lang['accesskey'] = 'Clau d\'accés';
$lang['accountupdated'] = 'Compte d\'usuari actualitzat';
$lang['action'] = 'Acció';
$lang['actioncontains'] = 'L\'acció conté';
$lang['actionstatus'] = 'Acció/Estat';
$lang['active'] = 'Actiu';
$lang['add'] = 'Afegir';
$lang['addbookmark'] = 'Afegir dracera';
$lang['addcontent'] = 'Afegir nou contingut';
$lang['added_content'] = 'Contingut afegit';
$lang['added_group'] = 'Grup afegit';
$lang['added_udt'] = 'Tag d\'usuari afegit';
$lang['added_user'] = 'Usuari afegit';
$lang['addgroup'] = 'Afegir nou grup';
$lang['additionaleditors'] = 'Editors addicionals';
$lang['additional_params'] = 'Paràmetres addicionals';
$lang['adduser'] = 'Afefir nou usuari';
$lang['addusertag'] = 'Afegir Tag d\'usuari';
$lang['admin'] = 'Administració del lloc';
$lang['adminaccess'] = 'Accés a entrar a admin';
$lang['admincallout'] = 'Administració de draceres';
$lang['admindescription'] = 'Funcions d\'administració de Lloc.';
$lang['adminhome'] = 'Centre d\'administració';
$lang['adminindent'] = 'Pantalla de contingut';
$lang['adminlog'] = 'Registre d\'administració';
$lang['adminlogcleared'] = 'El registre d\'administració s\'ha esborrat correctament';
$lang['adminlogdescription'] = 'Mostra el registre de qui ha fet què a l\'administració.';
$lang['adminlogempty'] = 'El registre d\'administració està buit';
$lang['adminpaging'] = 'Nombre d\'elements de contingut a mostrar per pàgina a la llista de pàgines';
$lang['adminpaneltitle'] = 'Penell administració CMS Made Simple';
$lang['adminprefs'] = 'Preferències d\'usuari';
$lang['adminprefsdescription'] = 'Aquí pots fixra preferències específiques per l\'administració del Lloc';
$lang['adminspecialgroup'] = 'Avís: Membres d\'aquest grup tindràn automàticament tots els permisos';
$lang['adminsystemtitle'] = 'Administració CMS';
$lang['admintheme'] = 'Tema d\'administració';
$lang['admin_enablenotifications'] = 'Permetre els usuaris de veure les notificacions<br/><em>(les notificacions es mostraran en totes les pàgines d\'administració)</em>';
$lang['advanced'] = 'Avançat';
$lang['aliasalreadyused'] = 'L\'àlies ja està essent utilitzat per una altra pàgina.  Canvia "Àlies de pàgina" a la pestanya "Opcions" per alguna latra cosa.';
$lang['aliasmustbelettersandnumbers'] = 'L\'àlies ha de constar només de lletres i dígits';
$lang['aliasnotaninteger'] = 'L\'àlies no pot ser un enter';
$lang['allpagesmodified'] = 'Totes les pàgines modificades!';
$lang['all_groups'] = 'Tots els grups';
$lang['apply'] = 'Aplicar';
$lang['applydescription'] = 'Desar els canvis i continuar editant';
$lang['assignmentchanged'] = 'Assignacions de grup actualitzades.';
$lang['assignments'] = 'Assignar usuaris';
$lang['author'] = 'Autor';
$lang['autoinstallupgrade'] = 'Instal.la o actualitza automàticament';
$lang['back'] = 'Enrere cap al menú';
$lang['backtoplugins'] = 'Enrere cap a la llista de plugins';
$lang['basic_attributes'] = 'Propietats bàsiques';
$lang['bookmarks'] = 'Draceres';
$lang['bulk_success'] = 'Operació en bloc actualitzada correctament.';
$lang['cachable'] = 'Memoritzable';
$lang['cachecleared'] = 'Memòria cau esborrada';
$lang['cachenotwritable'] = 'No es pot escriure a la carpeta de memòria cau.';
$lang['cancel'] = 'Cancel.lar';
$lang['canceldescription'] = 'Descartar canvis';
$lang['cantchmodfiles'] = 'No s\'han pogut canviar permisos en alguns arxius';
$lang['cantremove'] = 'No es pot esborrar';
$lang['cantremovefiles'] = 'Problema esborrant arxius (permisos?)';
$lang['caution'] = 'Precaució';
$lang['changehistory'] = 'Historial de canvis';
$lang['changepermissions'] = 'Canviar permisos';
$lang['checksumdescription'] = 'Valida la integritat dels arxius CMS tot comparant-los amb checksums coneguts';
$lang['checksum_passed'] = 'Tots els checksums coincideixen amb els de l\'arxiu pujat';
$lang['check_ini_set'] = 'Verifica ini_set';
$lang['check_ini_set_off'] = 'Pot ser que tinguis dificultats amb alguna funcionalitat sense aquesta capacitat. Aquesta verificació pot fallar si el fail_safe_mode està habilitat';
$lang['clear'] = 'Netejar';
$lang['clearadminlog'] = 'Neteja registre administració';
$lang['clearcache'] = 'Esborra memòria cau';
$lang['cms_install_information'] = 'Informació d\'instal.lació de CMS';
$lang['cms_version'] = 'Versió de CMS';
$lang['code'] = 'Codi';
$lang['config_information'] = 'Informació de Configuració';
$lang['config_writable'] = 'config.php modificable. És més segur si canvies els permisos a \'només lectura\'';
$lang['confirmcancel'] = 'Segur que vols descartar els canvis? Prem OK per descartar tots els canvis. Prem Cancel.lar per continuar editant.';
$lang['confirmdefault'] = 'Estàs segur de fixar la pàgina per defecte del lloc?';
$lang['confirmdeletedir'] = 'Segur que vols eliminar el directori i tot el seu contingut?';
$lang['connection_error'] = 'Les connexions exteriors de tipus http sembla que no funcionen! És possible que hi hagi un tallafocs o alguns ACL per les connexions externes?. Això provocarà que el mòdul \'Module Manager\', i potencialment altra funcionalitat, falli.';
$lang['connection_failed'] = 'La connexió ha fallat!';
$lang['content'] = 'Contingut';
$lang['contentadded'] = 'Contingut afegit correctament a la base de dades.';
$lang['contentdeleted'] = 'Contingut eliminat correctament de la base de dades.';
$lang['contentdescription'] = 'Aquí és on afegim i editem contingut.';
$lang['contentmanagement'] = 'Gestió de contingut';
$lang['contenttype'] = 'Tipus de contingut';
$lang['contenttype_content'] = 'Contingut';
$lang['contenttype_errorpage'] = 'Pàgina d\'error';
$lang['contenttype_pagelink'] = 'Enllaç intern';
$lang['contenttype_sectionheader'] = 'Capçalera';
$lang['contenttype_separator'] = 'Separador';
$lang['contentupdated'] = 'Contingut actualitzat correctament.';
$lang['contract'] = 'Contrau secció';
$lang['contractall'] = 'Contrau totes les seccions';
$lang['copy'] = 'Copiar';
$lang['copycontent'] = 'Copia element de contingut';
$lang['copystylesheet'] = 'Copiar fulla d\'estils';
$lang['copytemplate'] = 'Copiar plantilla';
$lang['copy_from'] = 'Copia de';
$lang['copy_paste_forum'] = 'Veure Informe  <em>(adecuat per penjar a fòrums)</em>';
$lang['copy_to'] = 'Copia a';
$lang['core'] = 'Nucli';
$lang['create'] = 'Crear';
$lang['createnewfolder'] = 'Crear nova carpeta';
$lang['create_dir_and_file'] = 'Verificant si el procés httpd pot crear un arxiu dins el directori que ha creat';
$lang['CSS'] = 'Fulles d\'estil';
$lang['cssalreadyused'] = 'Nom de CSS ja utilitzat';
$lang['cssmanagement'] = 'Gestió de CSS';
$lang['css_max_age'] = 'Màxim temps (en segons) durant el qual les fulles d\'estil es guarden al navegador';
$lang['currentassociations'] = 'Associacions actuals';
$lang['currentdirectory'] = 'Directory actual';
$lang['currentgroups'] = 'Grups actuals';
$lang['currentpages'] = 'Pàgines actuals';
$lang['currenttemplates'] = 'Plantilles actuals';
$lang['currentusers'] = 'Usuaris actuals';
$lang['custom404'] = 'Missatge d\'error 404 personalitzat';
$lang['dashboard'] = 'Veure Dashboard';
$lang['database'] = 'Base de dades';
$lang['databaseprefix'] = 'Prefix de base de dades';
$lang['databasetype'] = 'Tipus de base de dades';
$lang['date'] = 'Data';
$lang['date_format_string'] = 'Cadena de Format de Data';
$lang['date_format_string_help'] = '<em>strftime</em> cadena de format de data';
$lang['day'] = 'dia';
$lang['days'] = 'dies';
$lang['default'] = 'Per defecte';
$lang['defaultparentpage'] = 'Pàgina pare per defecte';
$lang['delete'] = 'Esborrar';
$lang['deleteconfirm'] = 'Segur que vols esborrar?';
$lang['deletecontent'] = 'Esborrar contingut';
$lang['deletepages'] = 'Esborrar aquestes pàgines?';
$lang['description'] = 'Descripció';
$lang['destinationnotfound'] = 'La pàgina triada no s\'ha pogut trobar o és invàlida';
$lang['destination_page'] = 'Pàgina de destinació';
$lang['directoryabove'] = 'directori per sobre el nivell actual';
$lang['directoryexists'] = 'Aquest directori ja existeix.';
$lang['disablesafemodewarning'] = 'Deshabilitar l\'avís de modalitat segura d\'administració';
$lang['disable_functions'] = 'disable_functions a PHP';
$lang['disable_wysiwyg'] = 'Deshabilita l\'editor WYSIWYG en aquesta pàgina (a desgrat de la configuració de la plantilla)';
$lang['down'] = 'Avall';
$lang['download'] = 'Descàrrega';
$lang['download_cksum_file'] = 'Descarregar l\'arxiu de checksum';
$lang['edit'] = 'Edita';
$lang['editbookmark'] = 'Editar dracera';
$lang['editconfiguration'] = 'Edita Configuració';
$lang['editeventhandler'] = 'Edita Gestor d\'Event';
$lang['editgroup'] = 'Edita Grup';
$lang['edituser'] = 'Edita Usuari';
$lang['editusertag'] = 'Edita Tag d\'usuari';
$lang['email'] = 'Adreça correu-e';
$lang['enablecustom404'] = 'Habilitar el missatge 404 personalitzat';
$lang['enablenotifications'] = 'Habilitar notificacions d\'usuari a la secció d\'administració';
$lang['enablesitedown'] = 'Habilitar missatge de Lloc caigut';
$lang['encoding'] = 'Codificació';
$lang['errorcantcreatefile'] = 'No s\'ha pogu crear un arxiu (problema de permisos?)';
$lang['errorchildcontent'] = 'Contingut que encara inclou contingut dependent. Elimina\'l primer.';
$lang['errordefaultpage'] = 'No es pot eliminar la pàgina per defecte actual. Posa\'n una altra per defecte primer.';
$lang['errordeletingassociation'] = 'Error esborrant associació';
$lang['errordeletingcontent'] = 'Error eliminant contingut (O bé la pàgina té fills o bé es tracta del contingut per defecte)';
$lang['errordeletingdirectory'] = 'No s\'ha pogut eliminar el directory. Problema de permisos?';
$lang['errordeletingfile'] = 'No s\'ha pogut esborrar arxiu. Problema de permisos?';
$lang['errordirectorynotwritable'] = 'Sense permís d\'escriptura en el directory';
$lang['errorgettingcontent'] = 'No s\'ha pogut recuperar informació per l\'objecte de contingut especificat';
$lang['errorinsertinggroup'] = 'Error insertant grup';
$lang['errorinsertingtag'] = 'Error insertant tag d\'usuari';
$lang['errorinsertinguser'] = 'Error insertant usuari';
$lang['errormodulenotfound'] = 'Error intern, no s\'ha pogut trobar la instància del mòdul';
$lang['errormodulenotloaded'] = 'Error intern, el mòdul no s\'ha instanciat';
$lang['errormoduleversionincompatible'] = 'El mòdul és incompatible amb aquesta versió de CMS';
$lang['errormodulewontload'] = 'Problema instanciant un mòdul disponible';
$lang['errornofilesexported'] = 'Error exportant arxius a xml';
$lang['errorpagealreadyinuse'] = 'Codi d\'error ja utilitzat';
$lang['errorsendingemail'] = 'Hi ha hagut un error enviant l\'email. Contacta l\'administrador.';
$lang['errorupdatetemplateallpages'] = 'Plantilla no activa';
$lang['errorupdatinggroup'] = 'Error actualitzant grup';
$lang['errorupdatingpages'] = 'Error actualitzant pàgines';
$lang['errorupdatingtemplate'] = 'Error actualitzant plantilla';
$lang['errorupdatinguser'] = 'Error actualitzant usuari';
$lang['errorupdatingusertag'] = 'Error actualitzant tag d\'usuari';
$lang['erroruserinuse'] = 'Aquest usuari encara té pàgines de contingut. Canvia la propietat a un altre usuari abans d\'esborra-lo.';
$lang['error_delete_default_parent'] = 'No pots esborrar el pare de la pàgina per defecte.';
$lang['error_nofileuploaded'] = 'No s\'ha pujat cap arxiu';
$lang['error_retrieving_file_list'] = 'Error recuperant llista d\'arxius';
$lang['error_type'] = 'Tipus d\'error';
$lang['error_udt_name_chars'] = 'Un nom UDT vàlid comença amb una lletra o guió baix, seguit per qualsevol nombre de lletres, xifres o quions baixos.';
$lang['error_udt_name_whitespace'] = 'Error: els Tags d\'usuari no poden tenir espais en el seu nom.';
$lang['error_uploadproblem'] = 'Error pujant un arxiu';
$lang['event'] = 'Acció';
$lang['eventhandlerdescription'] = 'Associar tags d\'usuari amb events';
$lang['eventhandlers'] = 'Accions';
$lang['event_description'] = 'Descricpió de l\'event';
$lang['event_desc_addglobalcontentpost'] = 'Enviat després de crear un bloc global de contingut';
$lang['event_desc_addglobalcontentpre'] = 'Enviat abans de crear un bloc global de contingut';
$lang['event_desc_addgrouppost'] = 'Enviat després de crear un nou grup';
$lang['event_desc_addgrouppre'] = 'Enviat abans de crear un nou grup';
$lang['event_desc_addstylesheetpost'] = 'Enviat després de crear una fulla d\'estil';
$lang['event_desc_addstylesheetpre'] = 'Enviat abans de crear una fulla d\'estil';
$lang['event_desc_addtemplatepost'] = 'Enviat després de crear una nova plantilla';
$lang['event_desc_addtemplatepre'] = 'Enviat abans de crear una nova plantilla';
$lang['event_desc_adduserdefinedtagpost'] = 'Enviat en afegir un tag d\'usuari';
$lang['event_desc_adduserdefinedtagpre'] = 'Enviat abans d\'afegir un tag d\'usuari';
$lang['event_desc_adduserpost'] = 'Enviat després de crear un usuari';
$lang['event_desc_adduserpre'] = 'Enviat en crear un nou usuari';
$lang['event_desc_changegroupassignpost'] = 'Enviat després de desar les assignacions de grup';
$lang['event_desc_changegroupassignpre'] = 'Enviat abans de desar les assignacions de grup';
$lang['event_desc_contentdeletepost'] = 'Enviat després d\'esborrar contingut del sistema';
$lang['event_desc_contentdeletepre'] = 'Enviat abans d\'esborrar contingut del sistema';
$lang['event_desc_contenteditpost'] = 'Enviat després de desar canvis a contingut';
$lang['event_desc_contenteditpre'] = 'Enviat abans de desar canvis a contingut';
$lang['event_desc_contentpostcompile'] = 'Enviat després que l\'smarty processi contingut';
$lang['event_desc_contentpostrender'] = 'Enviat abans que l\'html combinat sigui enviat al navegador';
$lang['event_desc_contentprecompile'] = 'Enviat abans d\'enviar contingut a l\'smarty per precessar';
$lang['event_desc_contentstylesheet'] = 'Enviat abans d\'enviar una fulla d\'estil al navegador';
$lang['event_desc_deleteglobalcontentpost'] = 'Enviat després d\'esborrar del sistema un bloc global de contingut';
$lang['event_desc_deleteglobalcontentpre'] = 'Enviat abans d\'esborrar del sistema un bloc global de contingut';
$lang['event_desc_deletegrouppost'] = 'Enviat després d\'esborrar un grup del sistema';
$lang['event_desc_deletegrouppre'] = 'Enviat abans d\'esborrar un grup del sistema';
$lang['event_desc_deletestylesheetpost'] = 'Enviat després d\'esborrar una fulla d\'estil del sistema';
$lang['event_desc_deletestylesheetpre'] = 'Enviat abans d\'esborrar una fulla d\'estil del sistema';
$lang['event_desc_deletetemplatepost'] = 'Enviat després d\'esborrar una plantilla del sistema';
$lang['event_desc_deletetemplatepre'] = 'Enviat abans d\'esborrar una plantilla del sistema';
$lang['event_desc_deleteuserdefinedtagpost'] = 'Enviat en esborrar un tag d\'usuari';
$lang['event_desc_deleteuserdefinedtagpre'] = 'Enviat abans d\'esborrar un tag d\'usuari';
$lang['event_desc_deleteuserpost'] = 'Enviat després d\'esborrar un usuari del sistema';
$lang['event_desc_deleteuserpre'] = 'Enviat en esborrar un usuari del sistema';
$lang['event_desc_editglobalcontentpost'] = 'Enviat després de desar canvis en un bloc global de contingut';
$lang['event_desc_editglobalcontentpre'] = 'Enviat abans de desar canvis en un bloc global de contingut';
$lang['event_desc_editgrouppost'] = 'Enviat després de desar canvis en un grup';
$lang['event_desc_editgrouppre'] = 'Enviat abans de desar canvis en un grup';
$lang['event_desc_editstylesheetpost'] = 'Enviat després de desar canvis en una fulla d\'estil';
$lang['event_desc_editstylesheetpre'] = 'Enviat abans de desar canvis en una fulla d\'estil';
$lang['event_desc_edittemplatepost'] = 'Enviat després de desar canvis a una plantilla';
$lang['event_desc_edittemplatepre'] = 'Enviat abans de desar canvis a una plantilla';
$lang['event_desc_edituserdefinedtagpost'] = 'Enviat en actualitzar un tag d\'usuari';
$lang['event_desc_edituserdefinedtagpre'] = 'Enviat abans d\'actualitzar un tag d\'usuari';
$lang['event_desc_edituserpost'] = 'Enviat després de desar canvis en un usuari';
$lang['event_desc_edituserpre'] = 'Enviat en desar canvis en un usuari';
$lang['event_desc_globalcontentpostcompile'] = 'Enviat després que un bloc global de contingut sigui processat per l\'smarty';
$lang['event_desc_globalcontentprecompile'] = 'Enviat abans d\'enviar un bloc global de contingut a l\'smarty';
$lang['event_desc_loginpost'] = 'Enviat després que un usuari entri al panell d\'aministració';
$lang['event_desc_logoutpost'] = 'Enviat després que un usuari deixi el panell d\'administració';
$lang['event_desc_moduleinstalled'] = 'Enviat en instal.lar un mòdul';
$lang['event_desc_moduleuninstalled'] = 'Enviat en desinstal.lar un mòdul';
$lang['event_desc_moduleupgraded'] = 'Enviat en actualitzar un mòdul';
$lang['event_desc_smartypostcompile'] = 'Enviat després que cap contingut destinat a l\'smarty sigui processat';
$lang['event_desc_smartyprecompile'] = 'Enviat abans que cap contingut destinat a l\'smarty sigui enviat per processar';
$lang['event_desc_templatepostcompile'] = 'Enviat abans que una plantilla sigui processada per l\'smarty';
$lang['event_desc_templateprecompile'] = 'Enviat abans d\'enviar una plantilla a l\'smarty per processar';
$lang['event_help_addglobalcontentpost'] = '<p>Enviat després de crear un bloc global de contingut.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'global_content\' - Referència a l\'objecte bloc global de contingut afectat.</li>
</ul>';
$lang['event_help_addglobalcontentpre'] = '<p>Enviat abans de crear un bloc global de contingut.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'global_content\' - Referència a l\'objecte bloc global de contingut afectat.</li>
</ul>';
$lang['event_help_addgrouppost'] = '<p>Enviat després de crear un nou grup.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'grup\' - Referència a l\'object de grup afectat.</li>
</ul>';
$lang['event_help_addgrouppre'] = '<p>Enviat abans de crear un ou grup.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'grup\' - Referència a l\'objecte d\'usuari afectat.</li>
</ul>';
$lang['event_help_addstylesheetpost'] = '<p>Enviat després de crear una nova fulla d\'estil.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'fulla d\'estil\' - Referència a l\'objecte fulla d\'estil afectat.</li>
</ul>';
$lang['event_help_addstylesheetpre'] = '<p>Enviat abans de crear una nova fulla d\'estils.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'fulla d\'estil\' - Referència a l\'objecte fulla d\'estil afectat.</li>
</ul>';
$lang['event_help_addtemplatepost'] = '<p>Enviat després de crear una nova plantilla.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'plantilla\' - Referència a l\'objecte plantilla afectat.</li>
</ul>';
$lang['event_help_addtemplatepre'] = '<p>Enviat abans de crear una nova plantilla.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'plantilla\' - Referència a l\'objecte plantilla afectat.</li>
</ul>';
$lang['event_help_adduserpost'] = '<p>Enviat després de crear un usuari.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'usuari\' - Referència a l\'objecte d\'usuari afectat.</li>
</ul>';
$lang['event_help_adduserpre'] = '<p>Enviat abans de crear un nou usuari.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'usuari\' - Referència a l\'objecte d\'usuari afectat.</li>
</ul>';
$lang['event_help_changegroupassignpost'] = '<p>Enviat abans de desar les assignacions de grup.</p>
<h4>Paràmetres></h4>
<ul>
<li>\'grup\' - Referència a l\'objecte de grup afectat.</li>
<li>\'usuaris\' -Llista de referències als objectes d\'usuari ara pertanyents al grup afectat.</li>';
$lang['event_help_changegroupassignpre'] = '<p>Enviat abans de desar les assignacions de grup.</p>
<h4>Paràmetres></h4>
<ul>
<li>\'grup\' - Referència a l\'objecte de grup.</li>
<li>\'usuaris\' - llista de referències a objectess d\'usuari pertanyents al grup.</li>';
$lang['event_help_contentdeletepost'] = '<p>Enviat després d\'esborrar contingut del sistema.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'contingut\' - Referència a l\'objecte contingut afectat.</li>
</ul>';
$lang['event_help_contentdeletepre'] = '<p>Enviat abans d\'esborrar del sistema contingut.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'contingut - Referència a l\'objecte contingut afectat.</li>
</ul>';
$lang['event_help_contenteditpost'] = '<p>Enviat després de desar canvis a contingut.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'contingut\' - Referència a l\'objecte contingut afectat.</li>
</ul>';
$lang['event_help_contenteditpre'] = '<p>Enviat abans de desar canvis a contingut.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'global_content\' - Referència a l\'objecte contingut afectat.</li>
</ul>';
$lang['event_help_contentpostcompile'] = '<p>Enviat després de preocessar contingut per part de l\'smarty.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'contingut\' - Referència al text de contingut afectat.</li>
</ul>';
$lang['event_help_contentpostrender'] = '<p>Enviat abans que l\'html combinat s\'enviï al navegador.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'contingut\' - Referència al text html.</li>
</ul>';
$lang['event_help_contentprecompile'] = '<p>Enviat abans d\'enviar contingut a l\'smarty per processar.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'contingut - Referència al text de contingut afectat.</li>
</ul>';
$lang['event_help_contentstylesheet'] = '<p>Enviat abans d\'enviar la fulla d\'estil al navegador.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'contingut\' - Referència al text de fulla d\'estil afectat.</li>
</ul>';
$lang['event_help_deleteglobalcontentpost'] = '<p>Enviat després d\'esborrar del sistema un bloc global de contingut.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'global_content\' - Referència a l\'objecte bloc global de contingut afectat.</li>
</ul>';
$lang['event_help_deleteglobalcontentpre'] = '<p>Enviat abans d\'esborrar del sistema un bloc global de contingut.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'global_content\' - Referència a l\'objecte bloc global de contingut afectat.</li>
</ul>';
$lang['event_help_deletegrouppost'] = '<p>Enviat després d\'esborrar del sistema un grup</p>
<h4>Paràmetres</h4>
<ul>
<li>\'grup\' - Referència a l\'objecte de grup afectat.</li>
</ul>';
$lang['event_help_deletegrouppre'] = '<p>Enviat abans d\'esborrar del sistema un grup.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'grup\' - Referència a l\'objecte de grup afectat.</li>
</ul>';
$lang['event_help_deletestylesheetpost'] = '<p>Enviat després d\'esborrar del sistema una fulla d\'estils.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'fulla d\'estil\' - Referència a l\'objecte fulla d\'estil afectat.</li>
</ul>';
$lang['event_help_deletestylesheetpre'] = '<p>Enviat abans d\'esborrar del sistema una fulla d\'estils.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'fulla d\'estil\' - Referència a l\'objecte fulla d\'estil afectat.</li>
</ul>';
$lang['event_help_deletetemplatepost'] = '<p>Enviat després d\'esborrar del sistema una plantilla.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'plantilla\' - Referència a l\'objecte plantilla afectat.</li>
</ul>';
$lang['event_help_deletetemplatepre'] = '<p>Enviat abans d\'esborrar del sistema una plantilla.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'plantilla\' - Referència a l\'objecte plantilla afectat.</li>
</ul>';
$lang['event_help_deleteuserpost'] = '<p>Enviat després d\'esborrar del sistema un usuari.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'usuari\' - Referència a l\'objecte d\'usuari afectat.</li>
</ul>';
$lang['event_help_deleteuserpre'] = '<p>Enviat abans d\'esborrar del sistema un usuari.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'usuari\' - Referència a l\'bjecte d\'usuari afectat.</li>
</ul>';
$lang['event_help_editglobalcontentpost'] = '<p>Enviat després de desar canvis a un bloc global de contingut.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'global_content\' - Referència a l\'objecte bloc global de contingut afectat.</li>
</ul>';
$lang['event_help_editglobalcontentpre'] = '<p>Enviat abans de desar canvis a un bloc global de contingut.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'global_content\' - Referència a l\'objecte bloc global de contingut afectat.</li>
</ul>';
$lang['event_help_editgrouppost'] = '<p>Enviat després de desar canvis a un grup.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'grup\' - Referènce a l\'objecte de grup afectat.</li>
</ul>';
$lang['event_help_editgrouppre'] = '<p>Enviat abans de desar canvis a un grup.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'grup\' - Referència a l\'bjecte de grup afectat.</li>
</ul>';
$lang['event_help_editstylesheetpost'] = '<p>Enviat després de desar canvis a una fulla d\'estils.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'fulla d\'estil\' - Referència a l\'objecte fulla d\'estil afectat.</li>
</ul>';
$lang['event_help_editstylesheetpre'] = '<p>Enviat abans de desar canvis a una fulla d\'estils.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'fulla d\'estil\' - Referència a l\'bjecte fulla d\'estil afectat.</li>
</ul>';
$lang['event_help_edittemplatepost'] = '<p>Enviat després de desar canvis a una plantilla.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'plantilla\' - Referència a l\'objecte plantilla afectat.</li>
</ul>';
$lang['event_help_edittemplatepre'] = '<p>Enviat abans de desar canvis a una plantilla.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'plantilla\' - Referència a l\'bjecte plantilla afectat.</li>
</ul>';
$lang['event_help_edituserpost'] = '<p>Enviat després de desar canvis a un usuari.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'usuari\' - Referència a l\'objecte d\'usuari afectat.</li>
</ul>';
$lang['event_help_edituserpre'] = '<p>Enviat abans de desar canvis a un usuari.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'usuari\' - Referència a l\'objecte d\'usuari afectat.</li>
</ul>';
$lang['event_help_globalcontentpostcompile'] = '<p>Enviat després de processar un bloc global de contingut per part de l\'smarty</p>
<h4>Paràmetres</h4>
<ul>
<li>\'global_content\' - Referència a l\'objecte bloc global de contingut afectat.</li>
</ul>';
$lang['event_help_globalcontentprecompile'] = '<p>Enviat abans d\'enviar a l\'smarty un bloc global de contingut global per processar.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'global_content\' - Referència a l\'objecte bloc global de contingut afectat.</li>
</ul>';
$lang['event_help_loginpost'] = '<p>Enviat després que un usuari entri al panell d\'administració</p>
<h4>Paràmetres</h4>
<ul>
<li>\'usuari\' - Referència a l\'objecte d\'usuari afectat.</li>
</ul>';
$lang['event_help_logoutpost'] = '<p>Enviat després que un usuari entri al panell d\'administració</p>
<h4>Paràmetres</h4>
<ul>
<li>\'usuari\' - Referència a l\'objecte d\'usuari afectat</li>
</ul>';
$lang['event_help_smartypostcompile'] = '<p>Enviat després que algún contingut destinat a l\'smarty hagi estat procesat.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'contingut\' - Referència al text afectat.</li>
</ul>';
$lang['event_help_smartyprecompile'] = '<p>Enviat abans que cap contingut s\'hagi enviat a l\'smarty per processar.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'contingut\' - Referència al text afectat.</li>
</ul>';
$lang['event_help_templatepostcompile'] = '<p>Enviat després de processar una plantilla per part de l\'smarty.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'plantilla\' - Referència al etxt de la plantilla afectat.</li>
</ul>';
$lang['event_help_templateprecompile'] = '<p>Enviat abans d\'enviar una plantilla a l\'smarty per processar.</p>
<h4>Paràmetres</h4>
<ul>
<li>\'plantilla\' - Referència al text de plantilla afectat.</li>
</ul>';
$lang['event_name'] = 'Nom d\'event';
$lang['execute'] = 'Executar';
$lang['expand'] = 'Amplia secció';
$lang['expandall'] = 'Amplia totes les seccions';
$lang['export'] = 'Exportar';
$lang['extensionsdescription'] = 'Mòduls, tags, i un assortit de divertiment.';
$lang['extra1'] = 'Atribut 1 de pàgina addicional';
$lang['extra2'] = 'Atribut 2 de pàgina addicional';
$lang['extra3'] = 'Atribut 32 de pàgina addicional';
$lang['failure'] = 'Error';
$lang['false'] = 'Fals';
$lang['filecreatedirnoname'] = 'No es pot crear un directori sense nom.';
$lang['filemanagement'] = 'Gestió d\'arxius';
$lang['filemanager'] = 'Gestor d\'arxius';
$lang['filemanagerdescription'] = 'Carregar i gestionar arxius.';
$lang['filename'] = 'Nom d\'arxiu';
$lang['filenotuploaded'] = 'L\'arxiu no s\'ha pogut carregar. Problema de permisos?';
$lang['files'] = 'Arxius';
$lang['filesize'] = 'Mida d\'arxiu';
$lang['files_checksum_failed'] = 'No s\'ha pogut generar un checksum pels arxius';
$lang['files_failed'] = 'Arxius que no han superat la verificació MD5';
$lang['files_not_found'] = 'Arxius que no s\'han trobat';
$lang['file_get_contents'] = 'Verifica file_get_contents';
$lang['file_uploads'] = 'Pujada d\'arxius';
$lang['file_url'] = 'Enllaç a l\'arxiu (enlloc de URL)';
$lang['filterbymodule'] = 'Filtrar per mòdul';
$lang['first'] = 'Primer';
$lang['firstname'] = 'Nom';
$lang['forge'] = 'Forja';
$lang['forgotpwprompt'] = 'Entra l\'usuari administrador. Un email serà enviat a l\'adreça de correu associada amb aquest nom d\'usuari amb nova informació d\'entrada.';
$lang['forums'] = 'Fòrums';
$lang['frontendlang'] = 'Idioma per defecte pel frontend';
$lang['frontendwysiwygtouse'] = 'Presentador wysiwyg';
$lang['gcb_wysiwyg'] = 'Habilitar BGC WYSIWYG';
$lang['gcb_wysiwyg_help'] = 'Habilitar l\'editor WYSIWYG en l\'edició d\'un bloc global de contingut';
$lang['gd_version'] = 'Versió de GD';
$lang['general_settings'] = 'Configuració general';
$lang['globalconfig'] = 'Configuració global';
$lang['globalmetadata'] = 'Metadades global';
$lang['global_umask'] = 'Màscara en crear arxius (umask)';
$lang['group'] = 'Grup';
$lang['groupassignmentdescription'] = 'Aquí pots assignar usuaris a grups';
$lang['groupassignments'] = 'Assignacions de grup';
$lang['groupmanagement'] = 'Gestió de grup';
$lang['groupname'] = 'Nom de grup';
$lang['grouppermissions'] = 'Permisos de grup';
$lang['groupperms'] = 'Permisos de grup';
$lang['grouppermsdescription'] = 'Fixa permisos i nivells d\'accés per grups';
$lang['groups'] = 'Grups';
$lang['groupsdescription'] = 'Aquí es gestionen els grups';
$lang['handler'] = 'Handler (tag d\'usuari)';
$lang['handle_404'] = 'Gestió personalitzada del 404';
$lang['hasdependents'] = 'Té dependències';
$lang['headtags'] = 'Tags capçalera';
$lang['help'] = 'Ajuda';
$lang['helpaddtemplate'] = '<p>Una plantilla és el que controla l\'aspecte del contingut del teu lloc web</p><p>Crea el layout aquí i afegeix les teves CSS a la secció de les fulles d\'estil per controlar l\'aparença de diversos elements.</p>';
$lang['helplisttemplate'] = '<p>Aquesta pàgina permet editar, esborrar i crear plantilles.</p><p>Per crear una nova plantilla, prem el botó <u>Afegir nova plantilla</u>.</p><p>Si vols configurar que totes les pàgines utilitzin la mateixa plantilla, pitja l\'enllaç <u>Per tot el contingut</u>.</p><p>Si vols duplicar la plantilla, pitja la icona<u>Copiar</u> i se\'t demanarà el nom per la nova plantilla.</p>';
$lang['helpwithsection'] = '%s Ajuda';
$lang['help_systeminformation'] = 'La informació mostrada a continuació s\'ha recollit des d\'una varietat de llocs, i resumida aquí per tal que puguis convenientment trobar part de la informació necesària quan es prova de diagnosticar un problema o petició d\'ajuda amb la instal.lació del teu CMS Made Simple';
$lang['hidefrommenu'] = 'Amaga del meú';
$lang['hide_help_links'] = 'Amaga enllaços d\'ajuda';
$lang['hide_help_links_help'] = 'Marca per tal de deshabilitar els enllaços del wiki i l\'ajuda del mòdul a les capçaleres de pàgina.';
$lang['home'] = 'Inici';
$lang['homepage'] = 'Pàgina d\'inici';
$lang['hostname'] = 'Servidor';
$lang['hour'] = 'hora';
$lang['hours'] = 'hores';
$lang['idnotvalid'] = 'Has donat un ID invàlid';
$lang['ignorenotificationsfrommodules'] = 'Ignorar notificacions des d\'aquests mòduls';
$lang['illegalcharacters'] = 'Caràcters invàlids al camp %s';
$lang['image'] = 'Imatge';
$lang['inactive'] = 'Inactiu';
$lang['indent'] = 'Indenta la llista de pàgines per emfatitzar la jerarquia';
$lang['informationmissing'] = 'Manca informació';
$lang['info_autoalias'] = 'Si aquest camp és buit, es crearà un àlies automàticament.';
$lang['info_deletepages'] = 'Nota: degut a restriccions de permisos, algunes de les pàgines triades per eliminar poden no aparèixer en la llista següent';
$lang['info_edituser_password'] = 'Canvia aquest camp per modiifcar el password d\'usuari';
$lang['info_edituser_passwordagain'] = 'Canvia aquest camp per modiifcar el password d\'usuari';
$lang['info_generate_cksum_file'] = 'Aquesta funció et permetrà generar un arxiu de checksum i desar-lo al teu ordinador local per validar-lo posteriorment. Això s\'hauria de fer just abans de desplegar el teu lloc web i/o després de qualsevol canvi de versió o modificació major.';
$lang['info_pagealias'] = 'Cal indicar un àlies únic per aquesta pàgina';
$lang['info_preview_notice'] = 'Atenció: aquest quadre de previsualització es comporta de manera molt semblant a la finestra del navegador, cosa que permet navegar fora de la pgina visualitzada inicialment. No obstant això, si ho fas et pots trobar amb un comportament inesperat. Si navegues fora del context i tornes, pots no veure el contingut no desat fins que facis un nou canvi a la pestanya principal i llavors tornis a carregar el previsualitzador. Quan afegeixes nou contingut, si navegues fora la pàgina no podràs tornar, i caldrà refrescar-la.';
$lang['info_sitedownexcludes'] = 'This parameter allows listing a comma separated list of ip addresses or networks that should not be subject to the sitedown mechanism.  This allows administrators to work on a site whilst anonymous visitors receive a sitedown message.<br/><br/>Addresses can be specified in the following formats:<br/>
1. xxx.xxx.xxx.xxx -- (exact IP address)<br/>
2. xxx.xxx.xxx.[yyy-zzz] -- (IP address range)<br/>
3. xxx.xxx.xxx.xxx/nn -- (nnn = number of bits, cisco style.  i.e:  192.168.0.100/24 = entire 192.168.0 class C subnet)';
$lang['info_validation'] = 'Aquesta funció compararà els checksums trobats en el fitxer pujat amb els arxius de la instal.lació actual. Pot ajudar a trobar problemes amb pujades, o exactament quins arxius han estat modificats en cas que el teu sistema hagi estat atacat (hacked).  Un arxiu de checksum es genera per cada versió de CMS Made simple des de la versió 1.4 en amunt.';
$lang['installed'] = 'Instal.lat';
$lang['installed_modules'] = 'Mòduls instal.lats';
$lang['invalid'] = 'Invàlid';
$lang['invalidcode'] = 'Codi invàlid';
$lang['invalidcode_brace_missing'] = 'Claus desaparellades';
$lang['invalidemail'] = 'L\'adreça que has entrat no és vàlida';
$lang['invalidparent'] = 'Cal triar una pàgina pare (contacta l\'administrador si no pots veure aquesta opció).';
$lang['invalid_test'] = 'Valor invàlid de paràmetre de prova';
$lang['itemid'] = 'ID element';
$lang['itemname'] = 'Nom d\'element';
$lang['itsbeensincelogin'] = 'Han passat %s de de la teva darrera visita';
$lang['jsdisabled'] = 'Per aquesta funció, cal tenir el javascript habilitat.';
$lang['language'] = 'Idioma';
$lang['last'] = 'Darrer';
$lang['lastname'] = 'Cognom';
$lang['last_modified_at'] = 'Darrera modificació de';
$lang['last_modified_by'] = 'Darrera modificacio feta per';
$lang['layout'] = 'Esquema';
$lang['layoutdescription'] = 'Opcions de layout del Lloc.';
$lang['loginprompt'] = 'Entra unes credencials vàlides per accedir al penell d\'administració';
$lang['logintitle'] = 'Entrada a l\'administració de CMS Made Simple';
$lang['login_info'] = 'Des d\'aquest punt, caldria considerar els paràmetres següents';
$lang['login_info_params'] = '<ol> 
  <li>Galetes habilitades al teu navegador</li> 
  <li>Javascript habilitat al teu navegador </li> 
  <li>Windows popup actiu per la següent adreça:</li> 
</ol>';
$lang['login_info_title'] = 'Informació';
$lang['logout'] = 'Sortir';
$lang['lostpw'] = 'Has oblidat el teu password';
$lang['lostpwemail'] = 'Estàs rebent aquest email perquè s\'ha fet una petició per canviar el password de (%) associat a aquest compte (%). Si realment vols reinicialitzar al password per aquest compte, simplement clica a l\'enllaç o enganxa\'l al teu navegador preferit:
%s

Si et sembla que això és incorrecte o generat per error, ignora aquest email i res no s\'haurà canviat.';
$lang['lostpwemailsubject'] = '[%s] Recuperació del password';
$lang['magic_quotes_gpc'] = 'Cometes màgiques per Get/Post/Cookie';
$lang['magic_quotes_gpc_on'] = 'Cometes simples, cometes dobles i contrabarra són marcades automàticament amb \'escape\'.';
$lang['magic_quotes_runtime'] = 'Cometes màgiques en temps d\'execució';
$lang['magic_quotes_runtime_on'] = 'La majoria de funcions que tornen un valor tindran les cometes marcades amb una contra-barra. Pots tenir problemes.';
$lang['main'] = 'Principal';
$lang['mainmenu'] = 'Menú principal';
$lang['managebookmarks'] = 'Gestió de draceres';
$lang['managebookmarksdescription'] = 'Aquí pots gestionar les draceres d\'administració';
$lang['master_admintheme'] = 'Aspecte d\'Administració per defecte (per la pàgina d\'entrada i nous usuaris)';
$lang['maximumversion'] = 'Versió màxima';
$lang['maximumversionsupported'] = 'Màxima versió suportada de CMSMS';
$lang['max_execution_time'] = 'Temps màxim d\'execució';
$lang['md5_function'] = 'funció md5';
$lang['memory_limit'] = 'Límit de memòria efectiu de PHP';
$lang['menutext'] = 'Text de menú';
$lang['menu_bookmarks'] = '[+]';
$lang['metadata'] = 'Metadades';
$lang['minimumversion'] = 'Versió mínima';
$lang['minimumversionrequired'] = 'Mínima versió necessària de CMSMS';
$lang['minute'] = 'minut';
$lang['minutes'] = 'minuts';
$lang['missingdependency'] = 'Dependència absent';
$lang['missingparams'] = 'Manquen paràmetres o són invàlids';
$lang['modifygroupassignments'] = 'Modifica assignacions de grup';
$lang['module'] = 'Mòdul';
$lang['moduleabout'] = 'Sobre el mòdul %s';
$lang['moduledescription'] = 'Els mòduls extenen el CMS Made Simple per proveïr-lo de tot tipus de funcionalitat a mida.';
$lang['moduleerrormessage'] = 'Missatge d\'error pel mòdul %s';
$lang['modulehelp'] = 'ajuda pel mòdul %s';
$lang['moduleinstalled'] = 'Mòdul ja instal.lat';
$lang['moduleinstallmessage'] = 'Missatge d\'instal.lació pel mòdul %s';
$lang['moduleinterface'] = '%s Interfase';
$lang['modules'] = 'Mòduls';
$lang['modulesnotwritable'] = 'No es pot escriure a la carpeta dels mòdula, si vols instal.lar mòduls descarregant el fitxer XML, necessites fer accessible a lectura/escriptura/execució (chmod 777) la carpeta dels mòduls';
$lang['moduleuninstallmessage'] = 'Missatge de desinstal.lació pel mòdul %s';
$lang['moduleupgradeerror'] = 'Error actualitzant el mòdul.';
$lang['module_help'] = 'Ajuda del mòdul';
$lang['module_name'] = 'Nom del mòdul';
$lang['move'] = 'Moure';
$lang['movecontent'] = 'Moure pàgines';
$lang['myaccount'] = 'El meu compte';
$lang['myaccountdescription'] = 'Aquí pots actualitzar els detalls del compte personal';
$lang['myprefs'] = 'Preferencies personals';
$lang['myprefsdescription'] = 'Aquí pots configurar l\'àrea d\'administració del Lloc per funcionar com vulguis.';
$lang['name'] = 'Nom';
$lang['needpermissionto'] = 'Cal el \'%s\' permís per efectuar aquesta funció.';
$lang['new_window'] = 'nova finestra';
$lang['next'] = 'Següent';
$lang['noaccessto'] = 'Sense accés a %s';
$lang['nodefault'] = 'No s\'ha escollit un valor per defecte';
$lang['noentries'] = 'No hi ha entrades';
$lang['nofieldgiven'] = 'No hia ha %s!';
$lang['nofiles'] = 'No hi ha arxius';
$lang['noncachable'] = 'No memoritzable';
$lang['none'] = 'Cap';
$lang['nopaging'] = 'Mostra tots els elements';
$lang['nopasswordforrecovery'] = 'No s\'ha definit email per aquest usuari. La recuperació del password no és possible. Contacta el teu administrador';
$lang['nopasswordmatch'] = 'Els passwords no coincideixen';
$lang['norealdirectory'] = 'El directori donat no existeix';
$lang['norealfile'] = 'L\'arxiu donat no existeix';
$lang['notifications'] = 'Notificacions';
$lang['notinstalled'] = 'No instal.lat';
$lang['no_bulk_performed'] = 'No s\'ha realitzat cap operació en bloc.';
$lang['no_file_url'] = 'Cap (Usa la URL superior)';
$lang['no_permission'] = 'No tens permís per realitzar aquesta funció';
$lang['of'] = 'de';
$lang['off'] = 'Apagat';
$lang['on'] = 'Connectat';
$lang['open_basedir'] = 'Open Basedir de PHP';
$lang['open_basedir_active'] = 'Sense verificació donat que open basedir és actiu';
$lang['options'] = 'Opcions';
$lang['order'] = 'Ordre';
$lang['order_too_large'] = 'L\'ordre no pot ser superior al del nombre de pàgines del nivell. No s\'han reordenat.';
$lang['order_too_small'] = 'L\'ordre no pot ser zero. No s\'han reordenat';
$lang['originator'] = 'Originador';
$lang['os_session_save_path'] = 'No es verifica degut al camí del SO';
$lang['other'] = 'Altres';
$lang['output_buffering'] = 'output_buffering de PHP';
$lang['owner'] = 'Propietari';
$lang['page'] = 'Pàgina';
$lang['pagealias'] = 'Àlies de pàgina';
$lang['pagedata_codeblock'] = 'Dades o lògica smarty que és específica d\'aquesta pàgina';
$lang['pagedefaults'] = 'Valors per defecte de la pàgina';
$lang['pagedefaultsdescription'] = 'Fixa els valor per defecte de les noves pàgines';
$lang['pagelink_circular'] = 'Un enllaç a pàgina no pot mostrar una altre enllaç com a destinació';
$lang['pages'] = 'Pàgines';
$lang['pagesdescription'] = 'Aquí podem afegir i editar pàgines i altre contingut';
$lang['pages_reordered'] = 'Pàgines reordenades amb èxit.';
$lang['page_metadata'] = 'Metadades específiques de pàgina';
$lang['page_reordered'] = 'Pàgina reordenada amb èxit.';
$lang['parameters'] = 'Paràmeters';
$lang['parent'] = 'Pare';
$lang['password'] = 'Contrasenya';
$lang['passwordagain'] = 'Password (altre cop)';
$lang['passwordchange'] = 'Sisplau, dóna un el passowrd';
$lang['passwordchangedlogin'] = 'Password canviat. Torna a entrar utilitzant les noves credencials.';
$lang['perform_validation'] = 'Realitza validació';
$lang['permission'] = 'Permís';
$lang['permissions'] = 'Permisos';
$lang['permissionschanged'] = 'Permisos actualitzats';
$lang['permission_information'] = 'Informació de permisos';
$lang['phpversion'] = 'Versió actual del PHP';
$lang['php_information'] = 'Informació de PHP';
$lang['pluginabout'] = 'Sobre el tag %s';
$lang['pluginhelp'] = 'Ajuda pel tag %s';
$lang['pluginmanagement'] = 'Gestió de connectors';
$lang['plugins'] = 'Connectors';
$lang['post_max_size'] = 'Mida màxima de Post';
$lang['preferences'] = 'Preferències';
$lang['preferencesdescription'] = 'Aquí defineixes diverses preferències d\'abast global.';
$lang['prefsupdated'] = 'Preferencies actualitzades.';
$lang['preview'] = 'Previsualització';
$lang['previewdescription'] = 'Previsualitzar canvis';
$lang['previous'] = 'Previa';
$lang['read'] = 'Llegir';
$lang['recentpages'] = 'Pàgines recents';
$lang['recoveryemailsent'] = 'Email enviat a l\'adreça desada. Verifica la teva bústia per més instruccions.';
$lang['register_globals'] = 'register_globals de PHP';
$lang['remote_connection_timeout'] = 'La connexió ha caducat!';
$lang['remote_response_404'] = 'Resposta remota: no s\'ha trobat!';
$lang['remote_response_error'] = 'Resposta remota: error!';
$lang['remote_response_ok'] = 'Resposta remota: ok!';
$lang['remove'] = 'Esborrar';
$lang['reorder'] = 'Reordenar';
$lang['reorderpages'] = 'Reordenar pags.';
$lang['results'] = 'Resultats';
$lang['safe_mode'] = 'Mode segur de PHP';
$lang['saveconfig'] = 'Desa configuració';
$lang['searchable'] = 'Aquesta pàgina és cercable';
$lang['search_string_find'] = 'Connexió correcta!';
$lang['selectall'] = 'Triat tot';
$lang['selecteditems'] = 'Sobre els triats';
$lang['selectgroup'] = 'Tria grup';
$lang['send'] = 'Enviar';
$lang['server_api'] = 'API de servidor';
$lang['server_db_type'] = 'Base de dades del servidor';
$lang['server_db_version'] = 'Versió de la base de dades del servidor';
$lang['server_information'] = 'Informació de servidor';
$lang['server_os'] = 'Sistema operatiu de servidor';
$lang['server_software'] = 'Programari de servidor';
$lang['session_save_path'] = 'Camí per desar sessió';
$lang['session_use_cookies'] = 'Les Sessions poden utilitzar Galetes (Cookies)';
$lang['setfalse'] = 'Fals';
$lang['settemplate'] = 'Fixa la plantilla';
$lang['settrue'] = 'Cert';
$lang['setup'] = 'Configuració avançada';
$lang['showall'] = 'Mostra tot';
$lang['showbookmarks'] = 'Mostra administració de draceres';
$lang['showinmenu'] = 'Mostra al menú';
$lang['showrecent'] = 'Mostra pàgines utilitzades recentment';
$lang['showsite'] = 'Mostra el lloc';
$lang['sibling_duplicate_order'] = 'Dues pàgines del mateix nivell no poden tenir el mateix ordre. No s\'han reordenat.';
$lang['siteadmin'] = 'Administració de Lloc';
$lang['sitedownexcludes'] = 'Exclou aquestes adreces dels Missatges de Lloc Caigut';
$lang['sitedownmessage'] = 'Missatge de Lloc caigut';
$lang['sitedownwarning'] = '<strong>Avís:</strong> El teu Lloc està mostrant ara mateix el missatge "Lloc caigut per manteniment" .  Elimina l\'arxiu %s per resoldre-ho.';
$lang['sitedown_settings'] = 'Configuració de lloc fora de línia';
$lang['sitename'] = 'Nom de Lloc';
$lang['siteprefs'] = 'Valors globals';
$lang['sqlerror'] = 'Error SQL a %s';
$lang['start_upgrade_process'] = 'Comença el procés de canvi de versió';
$lang['status'] = 'Estat';
$lang['subitems'] = 'Subelements';
$lang['submit'] = 'Enviar';
$lang['submitdescription'] = 'Desa canvis';
$lang['success'] = 'Èxit';
$lang['syntaxhighlightertouse'] = 'Triar el marcador de sintaxi a utilitzar';
$lang['systeminfo'] = 'Informació del Sistema';
$lang['systeminfodescription'] = 'Mostra diversos fragments d\'informació sobre el teu sistema que poden ser útils per diagnosticar problemes.';
$lang['systeminfo_copy_paste'] = 'Si et plau, copia i enganxa aquest text triat en el teu missatge al fòrum';
$lang['system_verification'] = 'Verificació del sistema';
$lang['tabindex'] = 'Pestanya índex';
$lang['tagdescription'] = 'Els tags són petites peces de funcionalitat que poden ser afegides al teu contingut i/o la plantilla';
$lang['tags'] = 'Etiquetes';
$lang['tagtousegcb'] = 'Tag per utilitzar aquest bloc';
$lang['target'] = 'Objectiu';
$lang['tempnam_function'] = 'Funció tempnam';
$lang['test'] = 'Provar';
$lang['test_allow_url_fopen_failed'] = 'Quan l\'opció de permetre \'url fopen\' es deshabilita, no podràs accedir a un objecte URL com un arxiu utilitzant els protocols ftp ni http.';
$lang['test_check_open_basedir_failed'] = 'Restricció Open Basedir activa. Pots tenir algunes dificultats amb funcionalitat d\'afegitons amb aquesta restricció.';
$lang['test_remote_url'] = 'Prova la URL remota';
$lang['test_remote_url_failed'] = 'Probablement no podràs obrir l\'arxiu en un servidor remot';
$lang['text_settemplate'] = 'Canvia la plantilla de les pàgines triades';
$lang['thumbnail'] = 'Contacte';
$lang['title'] = 'Títol';
$lang['titleattribute'] = 'Descripció (atribut títol)';
$lang['tools'] = 'Eines';
$lang['troubleshooting'] = '(resoldre problemes)';
$lang['true'] = 'Cert';
$lang['type'] = 'Tipus';
$lang['typenotvalid'] = 'Tipus invàlid';
$lang['unknown'] = 'Desconegut';
$lang['unlimited'] = 'Il.limitat';
$lang['untested'] = 'No provat';
$lang['up'] = 'Amunt';
$lang['updateperm'] = 'Actualitza permisos';
$lang['upload_cksum_file'] = 'Puja arxiu de checksum';
$lang['upload_max_filesize'] = 'Mida màxima de pujada';
$lang['url'] = 'Adreça web';
$lang['user'] = 'Usuari';
$lang['userdefinedtags'] = 'Tags d\'usuari';
$lang['usermanagement'] = 'Gestió d\'usuaris';
$lang['username'] = 'Nom d\'usuari';
$lang['usernameincorrect'] = 'Usuari o password incorrecte';
$lang['usernotfound'] = 'Usuario no trobat';
$lang['userprefs'] = 'Preferències d\'usuari';
$lang['users'] = 'Usuaris';
$lang['usersassignedtogroup'] = 'Usuaris assignats a grup %s';
$lang['usersdescription'] = 'Aquí es gestionen els usuaris';
$lang['usersgroups'] = 'Usuaris i Grups';
$lang['usersgroupsdescription'] = 'Elements relacionats amb usuaris i Grups.';
$lang['usertagadded'] = 'El tag d\'usuari s\'ha afegit correctament.';
$lang['usertagdeleted'] = 'El tag d\'usuari s\'ha esborrat correctament.';
$lang['usertagdescription'] = 'Tags que pots crear i modificar tu mateix per dur a terme tasques específiques, directament des del teu navegador.';
$lang['usertagexists'] = 'Ja existeix un tag amb aquest nom. Tria\'n un altre.';
$lang['usertags'] = 'Tags d\'usuari';
$lang['usertagupdated'] = 'El tag d\'usuari s\'ha modificat correctament.';
$lang['user_created'] = 'Draceres personals';
$lang['user_tag'] = 'Tag d\'usuari';
$lang['usewysiwyg'] = 'Utilitza un editor WYSIWYG pel contingut';
$lang['version'] = 'Versió';
$lang['view'] = 'Veure';
$lang['viewsite'] = 'Veure Lloc';
$lang['view_page'] = 'Veure aquesta pàgina en una nova finestra';
$lang['warning_mail_settings'] = 'La configuració de mail no s\'ha realitzat. Això podria interferir amb la capacitat del teu lloc web per enviar missatges. Hauries d\'anar a <a href="moduleinterface.php?module=CMSMailer">Extensions >> CMSMailer</a> i configurar els paràmetres de mail amb informació proporcionada pel teu proveïdor';
$lang['warning_safe_mode'] = '<strong><em>AVÍS:</em></strong> el modePHP Segur està habilitat.  Això causarà dificultats amb els arxius pujats via l\'interfase web, incloent imatges, temes i paquets de mòduls XML.  S\'et recomana contactar amb l\'administrador del lloc per veure si es pot deshabilitar el mode segur.';
$lang['warning_upgrade'] = '<em><strong>Avís:</strong></em> CMSMS és necessari per fer un canvi de versió';
$lang['warning_upgrade_info1'] = 'Tens en funcionament l\'esquema de la versió %s. i cal pujar-la a la versió %s';
$lang['warning_upgrade_info2'] = 'Si et plau, clica l\'enlaç següent: %s.';
$lang['welcomemsg'] = 'Benvingut %s';
$lang['welcome_user'] = 'Benvingut';
$lang['wiki'] = 'Viki';
$lang['wontdeletetemplateinuse'] = 'Aquestes plantilles s\'estan utilitzant i no es poden esborrar';
$lang['write'] = 'Escriure';
$lang['wysiwygtouse'] = 'Tria un WYSIWYG per utilitzar';
$lang['xml_function'] = 'Suport Bàsic XML (expat)';
$lang['dependencies'] = 'Dependències';
$lang['help_css_max_age'] = 'Aquest paràmetre s\'hauria de fixar relativament alt per llocs estàtics, i s\'hauria de fixar a 0 per llocs en desenvolupament.';
$lang['addtemplate'] = 'Afegir nova plantilla';
$lang['deletetemplate'] = 'Esborra fulles d\'estil';
$lang['deletetemplates'] = 'Esborra plantilles';
$lang['edittemplate'] = 'Edita Plantilla';
$lang['edittemplatesuccess'] = 'Plantilla modificada';
$lang['template'] = 'Plantilla';
$lang['templateexists'] = 'Nom de plantilla existent';
$lang['templates'] = 'Plantilla';
?>