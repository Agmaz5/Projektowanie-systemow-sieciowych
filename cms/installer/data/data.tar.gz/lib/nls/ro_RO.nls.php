<?php
#CMS - CMS Made Simple
#(c)2004 by Ted Kulp (wishy@users.sf.net)
#Visit our homepage at: http://www.cmsmadesimple.org
#
#This program is free software; you can redistribute it and/or modify
#it under the terms of the GNU General Public License as published by
#the Free Software Foundation; either version 2 of the License, or
#(at your option) any later version.
#
#This program is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#GNU General Public License for more details.
#You should have received a copy of the GNU General Public License
#along with this program; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

#NLS (National Language System) array.

#The basic idea and values was taken from then Horde Framework (http://horde.org)
#The original filename was horde/config/nls.php.
#The modifications to fit it for Gallery were made by Jens Tkotz
#(http://gallery.meanalto.com) 

#Ideas from Gallery's implementation made to CMS by Ted Kulp

#US English
#Created by: Ted Kulp <tedkulp@users.sf.net>
#Maintained by: Ted Kulp <tedkulp@users.sf.net>
#This is the default language

#Native language name
$nls['language']['ro_RO'] = 'Română';
$nls['englishlang']['ro_RO'] = 'Romanian';

#Possible aliases for language
$nls['alias']['ro'] = 'ro_RO';
$nls['alias']['Română'] = 'ro_RO' ;
$nls['alias']['rom'] = 'ro_RO' ;
$nls['alias']['romanian'] = 'ro_RO' ;
$nls['alias']['ro_RO.ISO8859-2'] = 'ro_RO' ;
$nls['alias']['ro_RO.ISO8859-16'] = 'ro_RO' ;

#Possible locale for language
$nls['locale']['ro_RO'] = 'ro_RO,ro_RO.utf8,ro_RO.UTF-8,ro_RO.utf-8,romanian,Romanian_Romania.1250';

#Encoding of the language
$nls['encoding']['ro_RO'] = 'UTF-8';

#Location of the file(s)
$nls['file']['ro_RO'] = array(dirname(__FILE__).'/ro_RO/admin.inc.php');

#Language setting for HTML area
# Only change this when translations exist in HTMLarea and plugin dirs
# (please send language files to HTMLarea development)

$nls['htmlarea']['ro_RO'] = 'ro';
?>
