<?php
$lang['automatedtask_failed'] = 'Automaattinen teht&auml;v&auml; ep&auml;onnistui';
$lang['automatedtask_success'] = 'Automaattinen teht&auml;v&auml; onnistui';
$lang['clearcache_taskname'] = 'Tyhjenn&auml; v&auml;limuisti';
$lang['clearcache_taskdescription'] = 'Tyhjenn&auml; ne tiedostot v&auml;limuistista, mitk&auml; ovat vanhempia kuin nykyiset';
$lang['testme'] = 'woot sain sen';
$lang['utma'] = '156861353.144823811.1251375439.1288623556.1288630766.361';
$lang['utmz'] = '156861353.1285804076.330.37.utmcsr=feedburner|utmccn=Feed: cmsmadesimple/blog (CMS Made Simple)|utmcmd=feed';
$lang['qca'] = 'P0-1379893105-1252067779694';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353.1.10.1288630766';
?>