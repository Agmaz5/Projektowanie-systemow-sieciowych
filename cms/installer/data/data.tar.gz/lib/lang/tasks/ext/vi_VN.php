<?php
$lang['adminlog_taskdescription'] = 'Việc n&agrave;y sẽ xo&aacute; c&aacute;c mục nhật k&yacute; cũ hơn ng&agrave;y đ&atilde; thiết lập. Tuổi nhật k&yacute; n&agrave;y c&oacute; thể điều chỉnh trong mục Thiết lập site.';
$lang['adminlog_taskname'] = 'Xo&aacute; c&aacute;c mục nhật k&yacute; cũ';
$lang['automatedtask_failed'] = 'C&ocirc;ng việc chạy tự động bị lỗi';
$lang['automatedtask_success'] = 'C&ocirc;ng việc chạy tự động ho&agrave;n th&agrave;nh';
$lang['clearcache_taskname'] = 'Xo&aacute; c&aacute;c tệp đệm';
$lang['clearcache_taskdescription'] = 'Tự động xo&aacute; c&aacute;c tệp khỏi thư mục bộ nhớ đệm c&oacute; tuổi cũ hơn số ng&agrave;y';
$lang['testme'] = 'Oh thấy rồi';
$lang['utma'] = '156861353.601192307.1333429677.1333429677.1333429677.1';
$lang['utmc'] = '156861353';
$lang['utmz'] = '156861353.1333429677.1.1.utmccn=(referral)|utmcsr=dev.cmsmadesimple.org|utmcct=/project/list|utmcmd=referral';
$lang['utmb'] = '156861353';
?>