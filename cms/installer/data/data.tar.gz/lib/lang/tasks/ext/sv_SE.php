<?php
$lang['adminlog_taskdescription'] = 'Denna uppgift kommer att radera loggposter &auml;ldre &auml;n en viss &aring;lder. Denna &aring;ldersgr&auml;ns kan st&auml;llas in p&aring; webbplatsen inst&auml;llningar.';
$lang['adminlog_taskname'] = 'Ta bort gamla loggposter';
$lang['automatedtask_failed'] = 'Automatisk uppgift misslyckades';
$lang['automatedtask_success'] = 'Automatisk uppgift lyckades';
$lang['clearcache_taskname'] = 'Rensa cache filer';
$lang['clearcache_taskdescription'] = 'Automatiskt rensa filer fr&aring;n cachekatalogen som &auml;r &auml;ldre &auml;n ett f&ouml;rinst&auml;llt antal dagar';
$lang['testme'] = 'va fick den';
$lang['utma'] = '156861353.173794243.1328216819.1328216819.1328216819.1';
$lang['utmz'] = '156861353.1328216819.1.1.utmcsr=forum.cmsmadesimple.org|utmccn=(referral)|utmcmd=referral|utmcct=/ucp.php';
$lang['qca'] = 'P0-1529175659-1310081076901';
$lang['utmb'] = '156861353.3.10.1328216819';
$lang['utmc'] = '156861353';
?>