<?php
$lang['adminlog_taskdescription'] = 'Questa operazione eliminer&agrave; i dati di log antecedenti ad un tempo determinato, che pu&ograve; essere specificato nelle preferenze del sito.';
$lang['adminlog_taskname'] = 'Elimina vecchi dati di log';
$lang['automatedtask_failed'] = 'Operazione automatica fallita';
$lang['automatedtask_success'] = 'Operazione automatica eseguita';
$lang['clearcache_taskname'] = 'Pulire i file di Cache';
$lang['clearcache_taskdescription'] = 'Cancella automaticamente i file dalla cartella di cache pi&ugrave; vecchi di un numero predefinito di giorni';
$lang['testme'] = 'eseguo';
$lang['utma'] = '156861353.1173279377.1339488425.1339488425.1339492135.2';
$lang['utmz'] = '156861353.1339488425.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>