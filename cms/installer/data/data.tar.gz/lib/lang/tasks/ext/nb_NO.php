<?php
$lang['adminlog_taskdescription'] = 'Denne oppgaven vil slette logg innlegg som er eldre enn en satt alder. Denne alder kan settes i nettstedspreferansene.';
$lang['adminlog_taskname'] = 'Slett gamle logginnlegg';
$lang['automatedtask_failed'] = 'Automatisert Task Mislykket';
$lang['automatedtask_success'] = 'Automatisert Task suksess';
$lang['clearcache_taskname'] = 'Tøm hurtigbuffer filer';
$lang['clearcache_taskdescription'] = 'Sletter automatisk filer fra mellomlagringskatalogen som er eldre enn et forhåndsbestemt antall dager';
$lang['testme'] = 'Jippy - fikk det til!';
?>