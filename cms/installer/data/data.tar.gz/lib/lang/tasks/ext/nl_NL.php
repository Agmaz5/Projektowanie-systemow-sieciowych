<?php
$lang['adminlog_taskdescription'] = 'Deze taak zal regels uit het logboek verwijderen die ouder zijn dan de opgegeven leeftijd. Deze leeftijd kan worden ingesteld bij de voorkeuren van de website.';
$lang['adminlog_taskname'] = 'Verwijder oude regels uit het logboek';
$lang['automatedtask_failed'] = 'Geautomatiseerde taak mislukt';
$lang['automatedtask_success'] = 'Geautomatiseerde taak geslaagd';
$lang['clearcache_taskname'] = 'Gebufferde bestanden verwijderd (Clear Cache)';
$lang['clearcache_taskdescription'] = 'Verwijder automatisch de bestanden in de Cache servermap die ouder zijn dan de ingestelde dagen';
$lang['testme'] = 'Gevonden!';
$lang['utma'] = '156861353.1406814545.1325588365.1325588365.1325588365.1';
$lang['utmz'] = '156861353.1325588365.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)';
$lang['qca'] = 'P0-856617467-1310370352588';
$lang['utmb'] = '156861353';
$lang['utmc'] = '156861353';
?>