<?php
$lang['adminlog_taskdescription'] = 'To zadanie usunie logi starsze od określonego czasu. Można go ustawić w administracji serwisem.';
$lang['adminlog_taskname'] = 'Usuń stare logi';
$lang['automatedtask_failed'] = 'Automatyczne zadanie zawiodło';
$lang['automatedtask_success'] = 'Automatyczne zadanie przeprowadzone pomyślnie';
$lang['clearcache_taskname'] = 'Wyczyść pliki cache';
$lang['clearcache_taskdescription'] = 'Automatycznie wyczyść z katalogu pliki cache, kt&oacute;re są starsze niż zadana liczba dni.';
$lang['testme'] = 'woot got it';
?>