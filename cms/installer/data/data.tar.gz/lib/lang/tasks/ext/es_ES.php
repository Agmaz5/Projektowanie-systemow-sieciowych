<?php
$lang['adminlog_taskdescription'] = 'Esta tarea borrar&aacute; las entradas de log anteriores al tiempo especificado. Este tiempo se puede configurar en las preferencias del sito.';
$lang['adminlog_taskname'] = 'Borra las entradas de log antiguas';
$lang['automatedtask_failed'] = 'Fall&oacute; la Tarea Automatizada';
$lang['automatedtask_success'] = 'Tarea Automatizada Realizada';
$lang['clearcache_taskname'] = 'Limpiar Archivos Cach&eacute;';
$lang['clearcache_taskdescription'] = 'Eliminar de forma autom&aacute;tica aquellos archivos del directorio cach&eacute; que sean anteriores a un n&uacute;mero predeterminado de d&iacute;as';
$lang['testme'] = 'woot listo!';
$lang['utma'] = '156861353.1328829624.1326880690.1326880690.1326880690.1';
$lang['utmz'] = '156861353.1326880690.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)';
$lang['utmb'] = '156861353';
$lang['utmc'] = '156861353';
?>