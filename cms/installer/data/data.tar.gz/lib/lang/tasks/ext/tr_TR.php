<?php
$lang['adminlog_taskdescription'] = 'This task will delete log entries older than a specified age. This age can be set in the site preferences.';
$lang['adminlog_taskname'] = 'Eski log kayıtlarını sil';
$lang['automatedtask_failed'] = 'Automated Task Failed';
$lang['automatedtask_success'] = 'Automated Task Success';
$lang['clearcache_taskname'] = '&Ouml;nbellek dosyalarını temizle';
$lang['clearcache_taskdescription'] = 'Automatically clear files from cache directory that are older than a preset number of days';
$lang['testme'] = 'woot got it';
$lang['utma'] = '156861353.1363139154.1364311709.1364311709.1364311709.1';
$lang['utmb'] = '156861353';
$lang['utmc'] = '156861353';
$lang['utmz'] = '156861353.1364311709.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)';
?>