<?php
$lang['automatedtask_failed'] = 'Az automatiz&aacute;lt feladat hib&aacute;s';
$lang['automatedtask_success'] = 'Az automatiz&aacute;lt feladat sikeres';
$lang['clearcache_taskname'] = 'A gyors&iacute;t&oacute;t&aacute;razott file-ok t&ouml;rl&eacute;se';
$lang['clearcache_taskdescription'] = 'Automatikusan t&ouml;rli a be&aacute;ll&iacute;tott időtartamn&aacute;l r&eacute;gebbi file-okat a gyors&iacute;t&oacute;t&aacute;r k&ouml;nyvt&aacute;r&aacute;b&oacute;l';
$lang['testme'] = 'J&eacute;&eacute;&eacute;, siker&uuml;lt';
$lang['qca'] = 'P0-132276779-1318620117065';
$lang['utma'] = '156861353.392447823.1321189053.1321216159.1321220027.7';
$lang['utmz'] = '156861353.1321189053.1.1.utmcsr=dev.cmsmadesimple.org|utmccn=(referral)|utmcmd=referral|utmcct=/project/list/module';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>