<?php
$lang['adminlog_taskdescription'] = 'Tugas ini akan menghapus entri log yang lebih tua dari usia yang ditentukan. Usia ini dapat diatur di preferensi situs.';
$lang['adminlog_taskname'] = 'Hapus entri log lama';
$lang['automatedtask_failed'] = 'Tugas Otomatis Gagal';
$lang['automatedtask_success'] = 'Tugas Otomatis Berhasil';
$lang['clearcache_taskname'] = 'Hapus File Cache';
$lang['clearcache_taskdescription'] = 'Secara otomatis menghapus file dari direktori cache yang lebih lama dari jumlah hari yang telah ditentukan';
$lang['gid'] = 'GA1.2.2090621558.1709215869';
$lang['ga_34B604LFFQ'] = 'GS1.1.1709215869.1.1.1709217607.59.0.0';
$lang['ga'] = 'GA1.1.1916813700.1709215868';
?>