<?php
$lang['adminlog_taskdescription'] = 'Esta tarefa ir&aacute; apagar as entradas do registo anteriores a um per&iacute;odo de tempo especificado. Este per&iacute;odo pode ser definido nas prefer&ecirc;ncias do site.';
$lang['adminlog_taskname'] = 'Apagar entradas do registo antigas';
$lang['automatedtask_failed'] = 'Tarefa autom&aacute;tica falhou';
$lang['automatedtask_success'] = 'Tarefa autom&aacute;tica com sucesso';
$lang['clearcache_taskname'] = 'Esvaziar cache';
$lang['clearcache_taskdescription'] = 'Automaticamente esvazia o cache a partir do direct&oacute;rio de cache que s&atilde;o mais antigos do que um n&uacute;mero predefinido de dias';
$lang['testme'] = 'woot got it ';
$lang['utma'] = '156861353.494797643.1328218505.1328218505.1328218505.1';
$lang['utmz'] = '156861353.1328218505.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)';
$lang['qca'] = 'P0-179206010-1319637219788';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>