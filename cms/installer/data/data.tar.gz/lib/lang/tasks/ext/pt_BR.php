<?php
$lang['automatedtask_failed'] = 'Tarefa Automatizada: Falhou ';
$lang['automatedtask_success'] = 'Tarefa Automatizada: Sucesso ';
$lang['clearcache_taskname'] = 'Limpar arquivos do cache';
$lang['clearcache_taskdescription'] = 'Limpar automaticamente os arquivos do cache que s&atilde;o mais velhos que um n&uacute;mero de dias pr&eacute;-determinados';
$lang['testme'] = 'o sistema conseguiu!';
$lang['qca'] = 'P0-100292355-1292339041903';
$lang['utmz'] = '156861353.1292339042.1.1.utmcsr=google|utmccn=(organic)|utmcmd=organic|utmctr=cmsms';
$lang['utma'] = '156861353.757843609.1292339042.1292339042.1292339042.1';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353.8.9.1292339165588';
?>