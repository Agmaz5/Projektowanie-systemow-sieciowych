<?php
$lang['page_not_exist'] = 'Page doesn\'t exist';
$lang['prev_label'] = 'Previous page:';
$lang['next_label'] = 'Next page:';
?>