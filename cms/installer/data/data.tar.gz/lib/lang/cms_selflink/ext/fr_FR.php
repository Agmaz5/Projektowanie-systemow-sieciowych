<?php
$lang['prev_label'] = 'Page précédente&nbsp;:';
$lang['next_label'] = 'Page suivante&nbsp;:';
?>