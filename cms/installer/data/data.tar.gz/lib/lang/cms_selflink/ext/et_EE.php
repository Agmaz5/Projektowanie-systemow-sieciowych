<?php
$lang['prev_label'] = 'Eelmine leht:';
$lang['next_label'] = 'J&auml;rgmine leht:';
$lang['utmz'] = '156861353.1329249366.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)';
$lang['utma'] = '156861353.1027764257.1329249366.1329249366.1329344099.2';
$lang['utmb'] = '156861353';
$lang['utmc'] = '156861353';
?>