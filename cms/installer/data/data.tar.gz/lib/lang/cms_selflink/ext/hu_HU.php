<?php
$lang['prev_label'] = 'Előző oldal:';
$lang['next_label'] = 'K&ouml;vetkező oldal: ';
$lang['utma'] = '156861353.251908092.1300186365.1300186365.1300186365.1';
$lang['utmb'] = '156861353';
$lang['utmc'] = '156861353';
$lang['utmz'] = '156861353.1300186365.1.1.utmccn=(referral)|utmcsr=cmsmadesimple.hu|utmcct=/forum/index.php/topic,477.15.html|utmcmd=referral';
?>