<?php
$lang['prev_label'] = 'Página anterior:';
$lang['next_label'] = 'Página seguinte:';
?>