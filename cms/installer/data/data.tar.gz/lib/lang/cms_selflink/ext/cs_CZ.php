<?php
$lang['prev_label'] = 'Předchoz&iacute; str&aacute;nka:';
$lang['next_label'] = 'N&aacute;sleduj&iacute;c&iacute; str&aacute;nka:';
$lang['utma'] = '156861353.682233951.1296068669.1297424355.1297458685.21';
$lang['utmz'] = '156861353.1296946283.16.4.utmcsr=feedburner|utmccn=Feed: cmsmadesimple/blog (CMS Made Simple)|utmcmd=feed';
$lang['qca'] = 'P0-796774439-1296068668929';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>