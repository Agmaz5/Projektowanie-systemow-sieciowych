<?php
$lang['prev_label'] = 'Predchádzajúca stránka:';
$lang['next_label'] = 'Nasledujúca stránka:';
?>