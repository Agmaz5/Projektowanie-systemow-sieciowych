<?php
$lang['prev_label'] = 'Vorherige Seite:';
$lang['next_label'] = 'N&auml;chste Seite:';
$lang['utma'] = '156861353.1815166024.1337452395.1337452395.1337452395.1';
$lang['utmc'] = '156861353';
$lang['utmz'] = '156861353.1337452395.1.1.utmccn=(direct)|utmcsr=(direct)|utmcmd=(none)';
$lang['utmb'] = '156861353';
?>