<?php
$lang['prev_label'] = 'Prethodna stranica:';
$lang['next_label'] = 'Slijedeća stranica:';
$lang['utma'] = '156861353.257390769.1275643143.1285138689.1285146831.76';
$lang['utmz'] = '156861353.1285097888.73.8.utmcsr=github.com|utmccn=(referral)|utmcmd=referral|utmcct=/tedkulp/silk';
$lang['qca'] = 'P0-1982634597-1275643142955';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353.1.10.1285146831';
?>