<?php
$lang['prev_label'] = 'Pagina previa:';
$lang['next_label'] = 'Pagina siguiente:';
$lang['utma'] = '156861353.305317536.1277281361.1284514388.1284571577.26';
$lang['utmz'] = '156861353.1284514388.25.8.utmccn=(organic)|utmcsr=google|utmctr=cms made simple translations|utmcmd=organic';
$lang['qca'] = 'P0-618030292-1277281361191';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>