<?php
$lang['prev_label'] = 'P&aacute;gina anterior:';
$lang['next_label'] = 'Pr&oacute;xima P&aacute;gina:';
$lang['qca'] = 'P0-100292355-1292339041903';
$lang['utmz'] = '156861353.1292339042.1.1.utmcsr=google|utmccn=(organic)|utmcmd=organic|utmctr=cmsms';
$lang['utma'] = '156861353.757843609.1292339042.1292339042.1292339042.1';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353.8.9.1292339165588';
?>