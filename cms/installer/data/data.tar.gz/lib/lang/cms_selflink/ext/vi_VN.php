<?php
$lang['prev_label'] = 'Trang trước:';
$lang['next_label'] = 'Trang sau:';
$lang['utma'] = '156861353.601192307.1333429677.1333429677.1333429677.1';
$lang['utmc'] = '156861353';
$lang['utmz'] = '156861353.1333429677.1.1.utmccn=(referral)|utmcsr=dev.cmsmadesimple.org|utmcct=/project/list|utmcmd=referral';
$lang['utmb'] = '156861353';
?>