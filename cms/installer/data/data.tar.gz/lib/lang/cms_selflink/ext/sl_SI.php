<?php
$lang['prev_label'] = 'Prej&scaron;nja stran:';
$lang['next_label'] = 'Naslednja stran:';
$lang['qca'] = 'P0-1458450664-1284573084918';
$lang['utmz'] = '156861353.1286352801.131.17.utmcsr=google|utmccn=(organic)|utmcmd=organic|utmctr=cmsms api docu';
$lang['utma'] = '156861353.1164361908.1285153768.1286727648.1286730193.160';
$lang['utmc'] = '156861353';
$lang['utmb'] = '156861353';
?>